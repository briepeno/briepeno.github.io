/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: PasswordValidator.java
 * Description:
 * This class validates passwords before a new account is created.
 * Passwords must contain at least eight characters, one uppercase
 * letter, one lowercase letter, one number, and one special
 * character. Spaces are not allowed.
 */

package com.cs360briannapeno.weighttrackapplication;

/**
 * Validates passwords used to create application accounts.
 */
public class PasswordValidator {

    // Minimum number of required characters
    private static final int MINIMUM_LENGTH = 8;

    // Prevent this utility class from being instantiated
    private PasswordValidator() {
    }

    // Validate Password
    public static ValidationResult validate(String password) {

        // Make sure a password was entered
        if (password == null || password.isEmpty()) {
            return new ValidationResult(
                    false,
                    "Enter a password"
            );
        }

        // Check the minimum length
        if (password.length() < MINIMUM_LENGTH) {
            return new ValidationResult(
                    false,
                    "Password must contain at least 8 characters"
            );
        }

        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        // Check each character in the password
        for (char character : password.toCharArray()) {
            if (Character.isWhitespace(character)) {
                return new ValidationResult(
                        false,
                        "Password cannot contain spaces"
                );

            } else if (Character.isUpperCase(character)) {
                hasUppercase = true;

            } else if (Character.isLowerCase(character)) {
                hasLowercase = true;

            } else if (Character.isDigit(character)) {
                hasNumber = true;

            } else {
                hasSpecialCharacter = true;
            }
        }

        // Check for an uppercase letter
        if (!hasUppercase) {
            return new ValidationResult(
                    false,
                    "Password must contain an uppercase letter"
            );
        }

        // Check for a lowercase letter
        if (!hasLowercase) {
            return new ValidationResult(
                    false,
                    "Password must contain a lowercase letter"
            );
        }

        // Check for a number
        if (!hasNumber) {
            return new ValidationResult(
                    false,
                    "Password must contain a number"
            );
        }

        // Check for a special character
        if (!hasSpecialCharacter) {
            return new ValidationResult(
                    false,
                    "Password must contain a special character"
            );
        }

        // The password passed every validation rule
        return new ValidationResult(
                true,
                null
        );
    }

    // Validation Result
    public static class ValidationResult {
        private final boolean valid;
        private final String errorMessage;

        public ValidationResult(
                boolean valid,
                String errorMessage) {
            this.valid = valid;
            this.errorMessage = errorMessage;
        }

        public boolean isValid() {
            return valid;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
}