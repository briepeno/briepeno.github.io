/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: WeightEntry.java
 * Description:
 * This model class represents one weight record stored in the
 * SQLite database. Each record contains a unique database ID,
 * a weight value, and the date the weight was entered. The same
 * model is used by the RecyclerView, progress calculator, and
 * weight-history chart.
 */

package com.cs360briannapeno.weighttrackapplication;

/**
 * Stores the information associated with one weight record.
 */
public class WeightEntry {
    // Weight record properties
    private final int id;
    private final double weight;
    private final String date;

    // Constructor
    public WeightEntry(
            int id,
            double weight,
            String date) {

        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    // Getters
    public int getId() {
        return id;
    }

    public double getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }
}