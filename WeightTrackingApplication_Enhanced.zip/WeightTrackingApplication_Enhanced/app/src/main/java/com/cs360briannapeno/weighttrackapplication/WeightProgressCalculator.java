/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: WeightProgressCalculator.java
 * Description:
 * This class calculates the user's weight progress using records
 * retrieved from the SQLite database. It determines the starting
 * weight, current weight, total change, recent change, remaining
 * weight, goal status, and percentage of the goal completed.
 */

package com.cs360briannapeno.weighttrackapplication;

// Java Imports
import java.util.List;

/**
 * Performs the calculations used by the progress dashboard.
 */
public class WeightProgressCalculator {

    // Constants
    private static final double COMPARISON_TOLERANCE = 0.001;

    // Constructor
    private WeightProgressCalculator() {
    }

    // Calculate Weight Progress
    public static Progress calculate(
            List<WeightEntry> entries,
            Double goalWeight) {

        // Return an empty result if no weights have been recorded
        if (entries == null || entries.isEmpty()) {
            return Progress.empty(goalWeight);
        }

        // Retrieve Weight Values
        // The first record represents the starting weight
        double startingWeight =
                entries.get(0).getWeight();

        // The last record represents the current weight
        double currentWeight =
                entries.get(entries.size() - 1).getWeight();

        // Use the previous entry to calculate the recent trend
        double previousWeight;
        if (entries.size() > 1) {
            previousWeight =
                    entries.get(entries.size() - 2).getWeight();
        } else {

            // There is no recent change when only one entry exists
            previousWeight = currentWeight;
        }

        // Calculate Weight Changes
        double totalChange =
                currentWeight - startingWeight;
        double recentChange =
                currentWeight - previousWeight;

        // Calculate Goal Progress
        double remainingWeight = 0;
        boolean goalReached = false;
        int progressPercentage = 0;

        if (goalWeight != null) {
            remainingWeight =
                    Math.abs(currentWeight - goalWeight);
            goalReached = hasReachedGoal(
                    startingWeight,
                    currentWeight,
                    goalWeight
            );
            progressPercentage = calculateProgressPercentage(
                    startingWeight,
                    currentWeight,
                    goalWeight
            );
        }

        // Return Calculated Results
        return new Progress(
                true,
                goalWeight != null,
                startingWeight,
                currentWeight,
                goalWeight == null ? 0 : goalWeight,
                totalChange,
                recentChange,
                remainingWeight,
                goalReached,
                progressPercentage
        );
    }

    // Determine Whether Goal Was Reached
    private static boolean hasReachedGoal(
            double startingWeight,
            double currentWeight,
            double goalWeight) {

        // The user has a weight-loss goal
        if (goalWeight < startingWeight) {
            return currentWeight <= goalWeight;
        }

        // The user has a weight-gain goal
        if (goalWeight > startingWeight) {
            return currentWeight >= goalWeight;
        }

        // The starting weight and goal weight are equal
        return Math.abs(currentWeight - goalWeight)
                < COMPARISON_TOLERANCE;
    }

    // Calculate Goal Percentage
    private static int calculateProgressPercentage(
            double startingWeight,
            double currentWeight,
            double goalWeight) {
        double goalDistance =
                Math.abs(goalWeight - startingWeight);

        // Avoid dividing by zero if the starting and goal
        // weights are the same
        if (goalDistance < COMPARISON_TOLERANCE) {
            if (hasReachedGoal(
                    startingWeight,
                    currentWeight,
                    goalWeight)) {
                return 100;
            }
            return 0;
        }

        // Determine whether the user is trying to gain or lose weight
        double direction =
                Math.signum(goalWeight - startingWeight);

        // Calculate progress in the correct direction
        double progressDistance =
                (currentWeight - startingWeight) * direction;
        double percentage =
                (progressDistance / goalDistance) * 100;
        // Prevent the percentage from going below 0 or above 100
        percentage = Math.max(0, percentage);
        percentage = Math.min(100, percentage);
        return (int) Math.round(percentage);
    }

    // Progress Result
    public static class Progress {
        private final boolean hasWeights;
        private final boolean hasGoal;
        private final double startingWeight;
        private final double currentWeight;
        private final double goalWeight;
        private final double totalChange;
        private final double recentChange;
        private final double remainingWeight;
        private final boolean goalReached;
        private final int progressPercentage;

        // Constructor
        public Progress(
                boolean hasWeights,
                boolean hasGoal,
                double startingWeight,
                double currentWeight,
                double goalWeight,
                double totalChange,
                double recentChange,
                double remainingWeight,
                boolean goalReached,
                int progressPercentage) {

            this.hasWeights = hasWeights;
            this.hasGoal = hasGoal;
            this.startingWeight = startingWeight;
            this.currentWeight = currentWeight;
            this.goalWeight = goalWeight;
            this.totalChange = totalChange;
            this.recentChange = recentChange;
            this.remainingWeight = remainingWeight;
            this.goalReached = goalReached;
            this.progressPercentage = progressPercentage;
        }

        // Empty Progress Result
        public static Progress empty(Double goalWeight) {
            return new Progress(
                    false,
                    goalWeight != null,
                    0,
                    0,
                    goalWeight == null ? 0 : goalWeight,
                    0,
                    0,
                    0,
                    false,
                    0
            );
        }

        // Getters
        public boolean hasWeights() {
            return hasWeights;
        }
        public boolean hasGoal() {
            return hasGoal;
        }
        public double getStartingWeight() {
            return startingWeight;
        }
        public double getCurrentWeight() {
            return currentWeight;
        }
        public double getGoalWeight() {
            return goalWeight;
        }
        public double getTotalChange() {
            return totalChange;
        }
        public double getRecentChange() {
            return recentChange;
        }
        public double getRemainingWeight() {
            return remainingWeight;
        }
        public boolean isGoalReached() {
            return goalReached;
        }
        public int getProgressPercentage() {
            return progressPercentage;
        }
    }
}