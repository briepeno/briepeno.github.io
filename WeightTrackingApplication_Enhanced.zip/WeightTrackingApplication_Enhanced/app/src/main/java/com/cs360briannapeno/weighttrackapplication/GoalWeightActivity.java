/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: GoalWeightActivity.java
 * Description:
 * This activity allows the user to enter and save a goal weight.
 * The enhanced version validates the value before saving it to the
 * SQLite database. Using the same validation class for weight and
 * goal entries reduces repeated code and keeps the application's
 * validation rules consistent.
 */
package com.cs360briannapeno.weighttrackapplication;

// Android Imports
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Allows the user to enter and save a goal weight.
 */
public class GoalWeightActivity extends AppCompatActivity {

    // User Interface Components
    private EditText editGoalWeight;
    private Button buttonSaveGoal;

    // Database
    private Database db;

    // Activity Creation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goalweight);

        // Hide the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Initialize User Interface Components
        editGoalWeight = findViewById(R.id.etGoalWeight);
        buttonSaveGoal = findViewById(R.id.btnSaveGoal);
        BottomNavigationView bottomNav =
                findViewById(R.id.bottomNavigationView);


        // Initialize Database
        db = new Database(this);

        // Display Existing Goal
        Double existingGoal = db.getGoalWeight();
        if (existingGoal != null) {
            editGoalWeight.setText(
                    String.valueOf(existingGoal)
            );
        }

        // Configure Bottom Navigation
        NavigationHelper.setupBottomNavigation(
                this,
                bottomNav,
                R.id.nav_goal_weight
        );

        // Save Goal Weight Button
        buttonSaveGoal.setOnClickListener(v -> {

            // Get the goal weight entered by the user
            String goalInput = editGoalWeight.getText()
                    .toString()
                    .trim();

            // Validate the entry before saving it
            WeightInputValidator.ValidationResult validation =
                    WeightInputValidator.validate(goalInput);

            // Display an error if the entry is invalid
            if (!validation.isValid()) {
                editGoalWeight.setError(
                        validation.getErrorMessage()
                );
                editGoalWeight.requestFocus();
                return;
            }

            // Remove any previous error message
            editGoalWeight.setError(null);

            // Get the validated goal weight
            double goalWeight = validation.getWeight();

            // Save Goal to Database
            if (db.setGoalWeight(goalWeight)) {
                Toast.makeText(
                        this,
                        "Goal weight saved!",
                        Toast.LENGTH_SHORT
                ).show();
            } else {
                Toast.makeText(
                        this,
                        "Error saving goal weight",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}