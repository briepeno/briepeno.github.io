/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: NotificationsActivity.java
 * Description:
 * This activity allows the user to save a phone number for SMS
 * goal notifications. The enhanced version validates and normalizes
 * U.S. phone numbers before saving them. It accepts formatted or
 * unformatted numbers and stores them using the +1 country code.
 */

package com.cs360briannapeno.weighttrackapplication;

// imports
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Controls the SMS notification settings screen.
 */
public class NotificationsActivity extends AppCompatActivity {

    // User interface components
    private EditText editPhoneNumber;
    private Button buttonEnableSms;

    // Saved user settings
    private SharedPreferences sharedPreferences;

    // Activity creation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        // Hide the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Initialize user interface components
        editPhoneNumber =
                findViewById(R.id.editPhoneNumber);

        buttonEnableSms =
                findViewById(R.id.buttonEnableSms);
        BottomNavigationView bottomNavigation =
                findViewById(R.id.bottomNavigationView);

        // Initialize saved settings
        sharedPreferences = getSharedPreferences(
                "user_prefs",
                Context.MODE_PRIVATE
        );

        // Display the previously saved number
        String savedNumber = sharedPreferences.getString(
                "sms_phone_number",
                ""
        );

        if (!savedNumber.isEmpty()) {
            editPhoneNumber.setText(
                    formatPhoneNumber(savedNumber)
            );
        }

        // Configure Bottom Navigation
        NavigationHelper.setupBottomNavigation(
                this,
                bottomNavigation,
                R.id.nav_settings
        );

        // Save phone number button
        buttonEnableSms.setOnClickListener(v -> {
            String phoneInput = editPhoneNumber
                    .getText()
                    .toString()
                    .trim();

            // Validate and normalize the entered number
            String normalizedNumber =
                    normalizePhoneNumber(phoneInput);
            if (normalizedNumber == null) {
                editPhoneNumber.setError(
                        "Enter a valid 10-digit U.S. phone number"
                );
                editPhoneNumber.requestFocus();
                return;
            }

            // Remove any previous error message
            editPhoneNumber.setError(null);

            // Save the number with the +1 country code
            sharedPreferences
                    .edit()
                    .putString(
                            "sms_phone_number",
                            normalizedNumber
                    )
                    .apply();

            // Display the number in a readable format
            String formattedNumber =
                    formatPhoneNumber(normalizedNumber);
            editPhoneNumber.setText(formattedNumber);
            Toast.makeText(
                    this,
                    "SMS notifications enabled for "
                            + formattedNumber,
                    Toast.LENGTH_SHORT
            ).show();
        });
    }

    // Validate and normalize phone number
    /**
     * Removes formatting characters and validates a U.S. phone
     * number. The area code and exchange cannot begin with 0 or 1.
     */

    private String normalizePhoneNumber(String phoneInput) {
        if (phoneInput == null
                || phoneInput.trim().isEmpty()) {
            return null;
        }

        // Remove parentheses, spaces, hyphens, and other formatting
        String digitsOnly =
                phoneInput.replaceAll("[^0-9]", "");

        // Remove an existing U.S. country code
        if (digitsOnly.length() == 11
                && digitsOnly.startsWith("1")) {
            digitsOnly =
                    digitsOnly.substring(1);
        }

        // A U.S. phone number must contain 10 digits
        if (digitsOnly.length() != 10) {
            return null;
        }

        // U.S. area codes cannot begin with 0 or 1
        char areaCodeFirstDigit =
                digitsOnly.charAt(0);
        if (areaCodeFirstDigit == '0'
                || areaCodeFirstDigit == '1') {
            return null;
        }

        // U.S. exchanges cannot begin with 0 or 1
        char exchangeFirstDigit =
                digitsOnly.charAt(3);

        if (exchangeFirstDigit == '0'
                || exchangeFirstDigit == '1') {
            return null;
        }

        // Store the number in international format
        return "+1" + digitsOnly;
    }

    // Format phone number for display
    /**
     * Formats +19785551234 as (978) 555-1234.
     */
    private String formatPhoneNumber(String phoneNumber) {
        String digitsOnly =
                phoneNumber.replaceAll("[^0-9]", "");

        // Remove the country code before formatting
        if (digitsOnly.length() == 11
                && digitsOnly.startsWith("1")) {
            digitsOnly =
                    digitsOnly.substring(1);
        }

        // Return the original value if it cannot be formatted
        if (digitsOnly.length() != 10) {
            return phoneNumber;
        }

        return "("
                + digitsOnly.substring(0, 3)
                + ") "
                + digitsOnly.substring(3, 6)
                + "-"
                + digitsOnly.substring(6);
    }
}