/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: NavigationHelper.java
 * Description:
 * This utility class manages the application's bottom navigation.
 * It removes repeated navigation listeners from each activity and
 * keeps the navigation behavior in one reusable location.
 */

package com.cs360briannapeno.weighttrackapplication;

// Imports
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Provides reusable bottom-navigation setup for each activity.
 */
public final class NavigationHelper {

    // Prevent this utility class from being instantiated
    private NavigationHelper() {
    }

    // Configure bottom navigation
    public static void setupBottomNavigation(
            AppCompatActivity activity,
            BottomNavigationView navigationView,
            int selectedItemId) {

        // Highlight the current screen
        navigationView.setSelectedItemId(
                selectedItemId
        );

        // Handle navigation selections
        navigationView.setOnItemSelectedListener(item -> {
            int selectedId =
                    item.getItemId();

            // Do not reopen the activity already being displayed
            if (selectedId == selectedItemId) {
                return true;
            }

            Class<?> destinationActivity =
                    getDestinationActivity(selectedId);

            // Return false if the selected item is unrecognized
            if (destinationActivity == null) {
                return false;
            }
            Intent intent = new Intent(
                    activity,
                    destinationActivity
            );

            // Reuse an existing activity instead of creating
            // unnecessary duplicate screens
            intent.addFlags(
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            );
            activity.startActivity(intent);
            return true;
        });
    }

    // Determine destination activity
    /**
     * Matches each navigation item with its activity.
     */
    private static Class<?> getDestinationActivity(
            int selectedItemId) {
        if (selectedItemId == R.id.nav_home) {
            return MainActivity.class;
        } else if (selectedItemId == R.id.nav_add_weight) {
            return AddWeightActivity.class;
        } else if (selectedItemId == R.id.nav_goal_weight) {
            return GoalWeightActivity.class;
        } else if (selectedItemId == R.id.nav_settings) {
            return NotificationsActivity.class;
        }
        return null;
    }
}
