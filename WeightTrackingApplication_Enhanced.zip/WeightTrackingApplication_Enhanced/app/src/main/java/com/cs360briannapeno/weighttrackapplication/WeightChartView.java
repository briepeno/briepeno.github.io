/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: WeightChartView.java
 * Description:
 * This custom view displays the user's weight records as a line
 * chart. Each point represents a saved weight, and the connecting
 * line shows how the user's weight has changed over time.
 */

package com.cs360briannapeno.weighttrackapplication;

// Imports
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Draws a line chart using chronological weight records.
 */
public class WeightChartView extends View {
    // Chart Data
    private final List<WeightEntry> weightEntries =
            new ArrayList<>();

    // Chart Paint Objects
    private final Paint gridPaint =
            new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint =
            new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pointPaint =
            new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint =
            new Paint(Paint.ANTI_ALIAS_FLAG);

    // Constructors
    public WeightChartView(Context context) {
        this(context, null);
    }

    //Constructor used when adding the chart through XML.
    public WeightChartView(
            Context context,
            @Nullable AttributeSet attributes) {
        this(context, attributes, 0);
    }

    //Constructor that also accepts a default style.
    public WeightChartView(
            Context context,
            @Nullable AttributeSet attributes,
            int defaultStyleAttribute) {
        super(
                context,
                attributes,
                defaultStyleAttribute
        );
        initializePaints();
    }

    // Initialize Chart Appearance
    private void initializePaints() {
        // Horizontal chart grid lines
        gridPaint.setColor(
                Color.parseColor("#5F6874")
        );
        gridPaint.setStrokeWidth(dpToPixels(1));

        // Weight trend line
        linePaint.setColor(
                Color.parseColor("#46C8B7")
        );
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(dpToPixels(3));

        // Individual weight points
        pointPaint.setColor(Color.WHITE);
        pointPaint.setStyle(Paint.Style.FILL);

        // Weight and date labels
        textPaint.setColor(
                Color.parseColor("#E5E7EB")
        );
        textPaint.setTextSize(dpToPixels(12));
    }

    // Update Chart Data
    public void setWeightEntries(
            List<WeightEntry> updatedEntries) {
        weightEntries.clear();
        if (updatedEntries != null) {
            weightEntries.addAll(updatedEntries);
        }

        // Improve accessibility by describing the chart
        if (weightEntries.isEmpty()) {
            setContentDescription(
                    "No weight history available"
            );
        } else {
            setContentDescription(
                    "Line chart showing "
                            + weightEntries.size()
                            + " weight entries"
            );
        }

        // Redraw the chart with the updated information
        invalidate();
    }

    // Draw Chart
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Display instructions when no weights exist
        if (weightEntries.isEmpty()) {
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(
                    "Add weights to see your trend",
                    getWidth() / 2f,
                    getHeight() / 2f,
                    textPaint
            );
            return;
        }

        // Chart Boundaries
        float chartLeft = dpToPixels(46);
        float chartRight = getWidth() - dpToPixels(16);
        float chartTop = dpToPixels(18);
        float chartBottom = getHeight() - dpToPixels(34);

        // Find Minimum and Maximum Weights
        double minimumWeight =
                weightEntries.get(0).getWeight();
        double maximumWeight = minimumWeight;
        for (WeightEntry entry : weightEntries) {
            minimumWeight = Math.min(
                    minimumWeight,
                    entry.getWeight()
            );
            maximumWeight = Math.max(
                    maximumWeight,
                    entry.getWeight()
            );
        }

        // Add Padding to Weight Range
        double weightRange =
                maximumWeight - minimumWeight;
        if (weightRange < 1) {

            // Prevent a flat chart when weights are equal
            minimumWeight -= 1;
            maximumWeight += 1;
        } else {
            double rangePadding =
                    weightRange * 0.15;
            minimumWeight -= rangePadding;
            maximumWeight += rangePadding;
        }

        // Draw Horizontal Grid Lines
        for (int lineNumber = 0;
             lineNumber <= 3;
             lineNumber++) {
            float yPosition =
                    chartTop
                            + ((chartBottom - chartTop)
                            * lineNumber / 3f);
            canvas.drawLine(
                    chartLeft,
                    yPosition,
                    chartRight,
                    yPosition,
                    gridPaint
            );
        }

        // Calculate Chart Point Positions
        float[] xPositions =
                new float[weightEntries.size()];
        float[] yPositions =
                new float[weightEntries.size()];
        Path weightPath = new Path();
        for (int index = 0;
             index < weightEntries.size();
             index++) {
            WeightEntry entry =
                    weightEntries.get(index);

            // Calculate horizontal position
            float xPosition;
            if (weightEntries.size() == 1) {
                xPosition =
                        (chartLeft + chartRight) / 2f;
            } else {
                xPosition =
                        chartLeft
                                + ((chartRight - chartLeft)
                                * index
                                / (weightEntries.size() - 1f));
            }

            // Calculate vertical position
            float yPosition = (float) (
                    chartBottom
                            - ((entry.getWeight() - minimumWeight)
                            / (maximumWeight - minimumWeight))
                            * (chartBottom - chartTop)
            );
            xPositions[index] = xPosition;
            yPositions[index] = yPosition;

            // Add the position to the line path
            if (index == 0) {
                weightPath.moveTo(
                        xPosition,
                        yPosition
                );
            } else {
                weightPath.lineTo(
                        xPosition,
                        yPosition
                );
            }
        }

        // Draw Weight Line
        canvas.drawPath(
                weightPath,
                linePaint
        );

        // Draw Individual Weight Points
        for (int index = 0;
             index < weightEntries.size();
             index++) {
            canvas.drawCircle(
                    xPositions[index],
                    yPositions[index],
                    dpToPixels(4),
                    pointPaint
            );
        }

        // Draw Maximum and Minimum Labels
        textPaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(
                formatWeight(maximumWeight),
                chartLeft - dpToPixels(7),
                chartTop + dpToPixels(4),
                textPaint
        );
        canvas.drawText(
                formatWeight(minimumWeight),
                chartLeft - dpToPixels(7),
                chartBottom + dpToPixels(4),
                textPaint
        );

        // Draw First and Last Dates
        textPaint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(
                weightEntries.get(0).getDate(),
                chartLeft,
                getHeight() - dpToPixels(10),
                textPaint
        );
        if (weightEntries.size() > 1) {
            textPaint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText(
                    weightEntries
                            .get(weightEntries.size() - 1)
                            .getDate(),
                    chartRight,
                    getHeight() - dpToPixels(10),
                    textPaint
            );
        }
    }

    // Format Weight Labels
    private String formatWeight(double weight) {

        return String.format(
                Locale.US,
                "%.1f",
                weight
        );
    }

    // Convert DP to Pixels
    private float dpToPixels(float dpValue) {
        return dpValue
                * getResources()
                .getDisplayMetrics()
                .density;
    }
}