/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: Database.java
 * Description:
 * This class manages the SQLite database used by the Weight Tracking
 * application. It handles user accounts, weight records, and goal
 * weights. The enhanced version includes a method that returns all
 * weight records in chronological order so they can be used by the
 * progress calculator and weight-history chart.
 */

package com.cs360briannapeno.weighttrackapplication;

//  Imports
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Manages the application's SQLite database.
 */
public class Database extends SQLiteOpenHelper {

    // Database Information
    private static final String DATABASE_NAME =
            "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Constructor
    public Database(Context context) {
        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }

    // Create Database Tables
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the user account table
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "username TEXT COLLATE NOCASE UNIQUE NOT NULL," +
                        "password TEXT NOT NULL)"
        );

        // Create the weight-history table
        db.execSQL(
                "CREATE TABLE weights (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "weight REAL," +
                        "date TEXT)"
        );

        // Create the goal-weight table
        db.execSQL(
                "CREATE TABLE goal (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "goalWeight REAL)"
        );
    }

    // Upgrade Database
    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS goal");
        onCreate(db);
    }

// Check Username
    /**
     * Checks whether a username already exists.
     * The comparison is case-insensitive.
     */
    public boolean usernameExists(String username) {
        SQLiteDatabase db =
                getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT id FROM users " +
                        "WHERE username = ? COLLATE NOCASE " +
                        "LIMIT 1",
                new String[]{username}
        );
        boolean usernameExists =
                cursor.moveToFirst();
        cursor.close();
        db.close();
        return usernameExists;
    }

// Register User
    /**
     * Creates a new account if the username is available.
     */
    public boolean registerUser(
            String username,
            String password) {

        // Prevent duplicate usernames
        if (usernameExists(username)) {
            return false;
        }

        SQLiteDatabase db =
                getWritableDatabase();
        ContentValues values =
                new ContentValues();
        values.put("username", username.trim());
        values.put("password", password);
        long result = db.insert(
                "users",
                null,
                values
        );

        db.close();
        return result != -1;
    }

    // Log In User
    /**
     * Checks whether the entered username and password exist.
     */
    public boolean loginUser(
            String username,
            String password) {
        SQLiteDatabase db =
                getReadableDatabase();
        Cursor cursor = db.query(
                "users",
                new String[]{"id"},
                "username=? COLLATE NOCASE AND password=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean userExists =
                cursor.getCount() > 0;

        cursor.close();
        db.close();

        return userExists;
    }

    // Add Weight
    public boolean addWeight(double weight) {
        SQLiteDatabase db =
                getWritableDatabase();
        ContentValues values =
                new ContentValues();
        values.put("weight", weight);
        values.put(
                "date",
                java.time.LocalDate.now().toString()
        );
        long result = db.insert(
                "weights",
                null,
                values
        );
        db.close();
        return result != -1;
    }

    // Delete Weight
    public boolean deleteWeight(int id) {
        SQLiteDatabase db =
                getWritableDatabase();
        int result = db.delete(
                "weights",
                "id=?",
                new String[]{String.valueOf(id)}
        );
        db.close();
        return result > 0;
    }

    // Get Latest Weight
    public Double getLatestWeight() {
        SQLiteDatabase db =
                getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT weight FROM weights " +
                        "ORDER BY id DESC LIMIT 1",
                null
        );
        Double weight = null;
        if (cursor.moveToFirst()) {
            weight = cursor.getDouble(0);
        }
        cursor.close();
        db.close();
        return weight;
    }

    // Get Goal Weight
    public Double getGoalWeight() {
        SQLiteDatabase db =
                getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT goalWeight FROM goal " +
                        "ORDER BY id DESC LIMIT 1",
                null
        );
        Double goalWeight = null;
        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(0);
        }
        cursor.close();
        db.close();
        return goalWeight;
    }
    // Save Goal Weight
    public boolean setGoalWeight(double goalWeight) {
        SQLiteDatabase db =
                getWritableDatabase();
        ContentValues values =
                new ContentValues();
        values.put("goalWeight", goalWeight);
        long result = db.insert(
                "goal",
                null,
                values
        );
        db.close();
        return result != -1;
    }

    // Get Weight History for RecyclerView
    public Cursor getAllWeights() {
        SQLiteDatabase db =
                getReadableDatabase();
        return db.rawQuery(
                "SELECT id, weight, date FROM weights " +
                        "ORDER BY id DESC",
                null
        );
    }

    // Get Chronological Weight History
    public List<WeightEntry> getWeightsChronological() {
        List<WeightEntry> weightEntries =
                new ArrayList<>();
        SQLiteDatabase db =
                getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT id, weight, date FROM weights " +
                        "ORDER BY id ASC",
                null
        );
        try {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                double weight = cursor.getDouble(1);
                String date = cursor.getString(2);
                WeightEntry entry = new WeightEntry(
                        id,
                        weight,
                        date
                );
                weightEntries.add(entry);
            }
        } finally {
            cursor.close();
            db.close();
        }
        return weightEntries;
    }
}