/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: AddWeightActivity.java
 * Description:
 * This activity allows the user to enter a weight, validates the
 * value, saves it to SQLite, and displays the weight history.
 * Navigation and SMS responsibilities are handled outside this
 * activity to reduce repeated code.
 */

package com.cs360briannapeno.weighttrackapplication;

// imports
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Controls weight entry and weight-history display.
 */
public class AddWeightActivity extends AppCompatActivity {
    // User interface components
    private EditText editWeight;
    private Button buttonAddWeight;
    private RecyclerView recyclerWeightList;


    // Application components
    private WeightAdapter adapter;
    private Database db;

    // Activity creation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Hide the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Initialize interface components
        editWeight =
                findViewById(R.id.editWeight);
        buttonAddWeight =
                findViewById(R.id.buttonAddWeight);
        recyclerWeightList =
                findViewById(R.id.recyclerWeightList);
        BottomNavigationView bottomNavigation =
                findViewById(R.id.bottomNavigationView);

        // Initialize database and weight history
        db = new Database(this);
        adapter = new WeightAdapter(db);
        recyclerWeightList.setLayoutManager(
                new LinearLayoutManager(this)
        );
        recyclerWeightList.setAdapter(adapter);

        // Configure reusable bottom navigation
        NavigationHelper.setupBottomNavigation(
                this,
                bottomNavigation,
                R.id.nav_add_weight
        );

        // Add Weight button
        buttonAddWeight.setOnClickListener(v -> {

            String weightInput =
                    editWeight.getText()
                            .toString()
                            .trim();

            // Validate the weight before saving it
            WeightInputValidator.ValidationResult validation =
                    WeightInputValidator.validate(weightInput);
            if (!validation.isValid()) {
                editWeight.setError(
                        validation.getErrorMessage()
                );
                editWeight.requestFocus();
                return;
            }

            // Remove any previous error
            editWeight.setError(null);
            double weight =
                    validation.getWeight();

            // Save the weight to SQLite
            if (db.addWeight(weight)) {
                Toast.makeText(
                        this,
                        "Weight added!",
                        Toast.LENGTH_SHORT
                ).show();

                // Clear the input field
                editWeight.setText("");

                // Reload the history from SQLite
                adapter.refresh();

            } else {
                Toast.makeText(
                        this,
                        "Error adding weight",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}