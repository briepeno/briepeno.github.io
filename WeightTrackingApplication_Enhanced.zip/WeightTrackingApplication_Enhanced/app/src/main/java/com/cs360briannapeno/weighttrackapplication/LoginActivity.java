/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: LoginActivity.java
 * Description:
 * This activity allows users to log in or create an account.
 * The enhanced version prevents duplicate usernames and validates
 * password strength before a new account can be created.
 */

package com.cs360briannapeno.weighttrackapplication;

// Imports
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Controls account creation and user login.
 */
public class LoginActivity extends AppCompatActivity {

    // User Interface Components
    private EditText editUsername;
    private EditText editPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;

    // Database
    private Database db;

    // Activity Creation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize User Interface Components
        editUsername =
                findViewById(R.id.editUsername);
        editPassword =
                findViewById(R.id.editPassword);
        buttonLogin =
                findViewById(R.id.btnLogin);
        buttonCreateAccount =
                findViewById(R.id.btnCreateAccount);

        // Initialize Database
        db = new Database(this);

        // Login Button
        buttonLogin.setOnClickListener(v -> {
            String username =
                    editUsername.getText()
                            .toString()
                            .trim();
            String password =
                    editPassword.getText()
                            .toString();

            // Make sure both fields contain information
            if (username.isEmpty()) {
                editUsername.setError(
                        "Enter a username"
                );
                editUsername.requestFocus();
                return;
            }
            if (password.isEmpty()) {
                editPassword.setError(
                        "Enter a password"
                );
                editPassword.requestFocus();
                return;
            }

            // Remove previous error messages
            editUsername.setError(null);
            editPassword.setError(null);

            // Check the entered credentials
            if (db.loginUser(username, password)) {
                Toast.makeText(
                        LoginActivity.this,
                        "Login successful!",
                        Toast.LENGTH_SHORT
                ).show();
                startActivity(
                        new Intent(
                                LoginActivity.this,
                                MainActivity.class
                        )
                );
                finish();
            } else {
                Toast.makeText(
                        LoginActivity.this,
                        "Invalid username or password",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Create Account Button
        buttonCreateAccount.setOnClickListener(v -> {
            String username =
                    editUsername.getText()
                            .toString()
                            .trim();
            String password =
                    editPassword.getText()
                            .toString();

            // Validate Username
            if (username.isEmpty()) {
                editUsername.setError(
                        "Enter a username"
                );
                editUsername.requestFocus();
                return;
            }

            // Check whether the username is already registered
            if (db.usernameExists(username)) {
                editUsername.setError(
                        "Username already exists"
                );
                editUsername.requestFocus();
                return;
            }

            // Validate Password
            PasswordValidator.ValidationResult validation =
                    PasswordValidator.validate(password);
            if (!validation.isValid()) {
                editPassword.setError(
                        validation.getErrorMessage()
                );
                editPassword.requestFocus();
                return;
            }

            // Remove previous error messages
            editUsername.setError(null);
            editPassword.setError(null);

            // Create Account
            if (db.registerUser(username, password)) {
                Toast.makeText(
                        LoginActivity.this,
                        "Account created!",
                        Toast.LENGTH_SHORT
                ).show();

                // Clear the password after account creation
                editPassword.setText("");
            } else {
                Toast.makeText(
                        LoginActivity.this,
                        "Unable to create account",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}