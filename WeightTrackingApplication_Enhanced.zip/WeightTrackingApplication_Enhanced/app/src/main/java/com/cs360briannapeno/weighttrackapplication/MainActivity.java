/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: MainActivity.java
 * Description:
 * This activity controls the application's progress dashboard. It
 * retrieves the user's weight history and goal from SQLite, passes
 * that information to the WeightProgressCalculator, and displays
 * the calculated results. It also updates the weight-history chart
 * and checks whether the user has reached their goal weight.
 */

package com.cs360briannapeno.weighttrackapplication;

// Imports
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.DecimalFormat;
import java.util.List;

/**
 * Controls the home-screen progress dashboard.
 */
public class MainActivity extends AppCompatActivity {
    // Constants
    private static final int SMS_PERMISSION_CODE = 200;
    // Dashboard Components
    private TextView textStartingWeight;
    private TextView textCurrentWeight;
    private TextView textGoalWeight;
    private TextView textTotalChange;
    private TextView textRemainingWeight;
    private TextView textRecentTrend;
    private TextView textProgressPercentage;
    private ProgressBar progressGoal;
    private WeightChartView weightChart;

    // Application Components
    private Database db;
    private final DecimalFormat weightFormat =
            new DecimalFormat("0.#");
    private boolean smsSent = false;

    // Activity Creation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Hide the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Initialize Dashboard Components
        textStartingWeight =
                findViewById(R.id.textStartingWeight);
        textCurrentWeight =
                findViewById(R.id.textCurrentWeight);
        textGoalWeight =
                findViewById(R.id.textGoalWeight);
        textTotalChange =
                findViewById(R.id.textTotalChange);
        textRemainingWeight =
                findViewById(R.id.textRemainingWeight);
        textRecentTrend =
                findViewById(R.id.textRecentTrend);
        textProgressPercentage =
                findViewById(R.id.textProgressPercentage);
        progressGoal =
                findViewById(R.id.progressGoal);
        weightChart =
                findViewById(R.id.weightChart);
        BottomNavigationView bottomNavigation =
                findViewById(R.id.bottomNavigationView);

        // Initialize Database
        db = new Database(this);

        // Configure Bottom Navigation
        NavigationHelper.setupBottomNavigation(
                this,
                bottomNavigation,
                R.id.nav_home
        );
    }

    // Refresh Dashboard
    @Override
    protected void onResume() {
        super.onResume();
        refreshDashboard();
    }

    // Load and Display Progress
    private void refreshDashboard() {
        // Get all weights in chronological order
        List<WeightEntry> weightEntries =
                db.getWeightsChronological();

        // Get the user's most recently saved goal
        Double goalWeight =
                db.getGoalWeight();

        // Calculate the user's progress
        WeightProgressCalculator.Progress progress =
                WeightProgressCalculator.calculate(
                        weightEntries,
                        goalWeight
                );

        // Update Weight Chart
        weightChart.setWeightEntries(weightEntries);

        // Display Weight Information
        if (!progress.hasWeights()) {

            // No weight records are available
            textStartingWeight.setText(
                    R.string.no_weight_recorded
            );
            textCurrentWeight.setText(
                    R.string.no_weight_recorded
            );
            textTotalChange.setText(
                    R.string.not_available
            );
            textRecentTrend.setText(
                    R.string.add_weights_for_trend
            );
        } else {

            // Display starting and current weights
            textStartingWeight.setText(
                    formatPounds(
                            progress.getStartingWeight()
                    )
            );
            textCurrentWeight.setText(
                    formatPounds(
                            progress.getCurrentWeight()
                    )
            );

            // Display total weight change
            textTotalChange.setText(
                    formatTotalChange(
                            progress.getTotalChange()
                    )
            );

            // Display the change since the previous entry
            textRecentTrend.setText(
                    formatRecentTrend(
                            progress.getRecentChange(),
                            weightEntries.size()
                    )
            );
        }

        // Display Goal Information
        if (!progress.hasGoal()) {
            textGoalWeight.setText(
                    R.string.no_goal_set
            );
            textRemainingWeight.setText(
                    R.string.not_available
            );
            textProgressPercentage.setText(
                    R.string.set_goal_for_progress
            );
            progressGoal.setProgress(0);
        } else {

            // Display the user's goal weight
            textGoalWeight.setText(
                    formatPounds(
                            progress.getGoalWeight()
                    )
            );

            // Update the goal progress bar
            progressGoal.setProgress(
                    progress.getProgressPercentage()
            );
            textProgressPercentage.setText(
                    getString(
                            R.string.goal_progress_percentage,
                            progress.getProgressPercentage()
                    )
            );

            // Display Remaining Weight
            if (!progress.hasWeights()) {
                textRemainingWeight.setText(
                        R.string.not_available
                );
            } else if (progress.isGoalReached()) {
                textRemainingWeight.setText(
                        R.string.goal_reached
                );
            } else {
                textRemainingWeight.setText(
                        getString(
                                R.string.pounds_remaining,
                                weightFormat.format(
                                        progress.getRemainingWeight()
                                )
                        )
                );
            }
        }

        // Check Goal Notification
        if (progress.hasWeights()
                && progress.hasGoal()
                && progress.isGoalReached()
                && !smsSent) {
            checkPermissionAndSendSms(goalWeight);
        }
    }

    // Format Weight
    private String formatPounds(double weight) {
        return getString(
                R.string.pounds_value,
                weightFormat.format(weight)
        );
    }

    // Format Total Change
    private String formatTotalChange(double totalChange) {
        // Treat very small differences as no change
        if (Math.abs(totalChange) < 0.001) {
            return getString(
                    R.string.no_change
            );
        }
        if (totalChange < 0) {
            return getString(
                    R.string.pounds_lost,
                    weightFormat.format(
                            Math.abs(totalChange)
                    )
            );
        } else {
            return getString(
                    R.string.pounds_gained,
                    weightFormat.format(totalChange)
            );
        }
    }

    // Format Recent Trend
    private String formatRecentTrend(
            double recentChange,
            int numberOfEntries) {

        // At least two entries are required to calculate a trend
        if (numberOfEntries < 2) {
            return getString(
                    R.string.add_another_weight_for_trend
            );
        }

        // Treat very small differences as no change
        if (Math.abs(recentChange) < 0.001) {
            return getString(
                    R.string.no_change_since_last_entry
            );
        }

        if (recentChange < 0) {
            return getString(
                    R.string.trend_down,
                    weightFormat.format(
                            Math.abs(recentChange)
                    )
            );
        } else {
            return getString(
                    R.string.trend_up,
                    weightFormat.format(recentChange)
            );
        }
    }

    // Check SMS Permission
    private void checkPermissionAndSendSms(
            Double goalWeight) {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        } else {
            sendGoalSms(goalWeight);
        }
    }

    // Send Goal SMS
    private void sendGoalSms(Double goalWeight) {
        SharedPreferences preferences =
                getSharedPreferences(
                        "user_prefs",
                        MODE_PRIVATE
                );
        String phoneNumber =
                preferences.getString(
                        "sms_phone_number",
                        null
                );
        if (phoneNumber == null
                || phoneNumber.isEmpty()) {
            Toast.makeText(
                    this,
                    "No phone number saved in settings.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }
        String message =
                "Congratulations! You reached your goal weight of "
                        + goalWeight
                        + " lbs!";
        try {
            SmsManager smsManager =
                    SmsManager.getDefault();
            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );
            Toast.makeText(
                    this,
                    "Goal reached! SMS sent.",
                    Toast.LENGTH_LONG
            ).show();
            smsSent = true;
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "SMS failed to send.",
                    Toast.LENGTH_LONG
            ).show();
            e.printStackTrace();
        }
    }

    // SMS Permission Result
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {
                Double goalWeight =
                        db.getGoalWeight();
                if (goalWeight != null) {
                    sendGoalSms(goalWeight);
                }
            } else {
                Toast.makeText(
                        this,
                        "SMS permission denied",
                        Toast.LENGTH_SHORT
                ).show();
            }
        }
    }
}