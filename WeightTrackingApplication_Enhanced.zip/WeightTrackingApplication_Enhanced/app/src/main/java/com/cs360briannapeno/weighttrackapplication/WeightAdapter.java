/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: WeightAdapter.java
 * Description:
 * This adapter retrieves weight records from the SQLite database
 * and displays them in a RecyclerView. The enhanced version includes
 * a refresh method that reloads the database after a weight is added
 * or deleted. This ensures that the displayed history always matches
 * the information stored in the database.
 */

package com.cs360briannapeno.weighttrackapplication;

// Android Imports
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Displays weight records inside the weight-history RecyclerView.
 */
public class WeightAdapter
        extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    // Variables
    private final List<WeightEntry> weightList;
    private final Database db;

    // Constructor
    public WeightAdapter(Database db) {
        this.db = db;
        this.weightList = new ArrayList<>();
        loadWeights();
    }
    // Load Weight History
    private void loadWeights() {
        // Remove the old records before reloading the list
        weightList.clear();
        Cursor cursor = db.getAllWeights();
        try {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                double weight = cursor.getDouble(1);
                String date = cursor.getString(2);
                WeightEntry entry = new WeightEntry(
                        id,
                        weight,
                        date
                );
                weightList.add(entry);
            }
        } finally {
            // Always close the cursor when finished
            cursor.close();
        }
    }

    // Refresh Weight History
    public void refresh() {
        loadWeights();
        notifyDataSetChanged();
    }

    // Create View Holder
    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(
                        R.layout.item_delete,
                        parent,
                        false
                );
        return new WeightViewHolder(view);
    }

    // Display Weight Record
    @Override
    public void onBindViewHolder(
            @NonNull WeightViewHolder holder,
            int position) {
        WeightEntry entry = weightList.get(position);

        // Display the weight and date
        String weightText =
                entry.getWeight()
                        + " lbs ("
                        + entry.getDate()
                        + ")";
        holder.textWeight.setText(weightText);

        // Delete Weight Button
        holder.buttonDelete.setOnClickListener(v -> {
            int adapterPosition =
                    holder.getBindingAdapterPosition();
            // Make sure the item still has a valid position
            if (adapterPosition == RecyclerView.NO_POSITION) {
                return;
            }
            WeightEntry selectedEntry =
                    weightList.get(adapterPosition);
            // Delete the record from the database
            if (db.deleteWeight(selectedEntry.getId())) {
                // Reload the list after deletion
                refresh();
            }
        });
    }

    // Weight Record Count
    @Override
    public int getItemCount() {
        return weightList.size();
    }

    // View Holder
    static class WeightViewHolder
            extends RecyclerView.ViewHolder {
        private final TextView textWeight;
        private final ImageButton buttonDelete;
        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            textWeight =
                    itemView.findViewById(
                            R.id.textWeightValue
                    );
            buttonDelete =
                    itemView.findViewById(
                            R.id.buttonDelete
                    );
        }
    }
}