/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: WeightInputValidator.java
 * Description:
 * This class validates weight values before they are saved to the
 * SQLite database. It checks for blank entries, nonnumeric values,
 * and weights outside the accepted range.
 */
package com.cs360briannapeno.weighttrackapplication;

/**
 * WeightInputValidator
 *
 * Validates weight entries before they are saved to the database.
 * This prevents blank, nonnumeric, or unreasonable values from
 * being added to the application.
 */
public class WeightInputValidator {

    // Weight Limits
    private static final double MIN_WEIGHT = 50.0;
    private static final double MAX_WEIGHT = 1000.0;

    // Constructor
    private WeightInputValidator() {
    }

    // Weight Validation
    public static ValidationResult validate(String input) {

        // Make sure the user entered something
        if (input == null || input.trim().isEmpty()) {
            return new ValidationResult(
                    false,
                    0,
                    "Enter a weight"
            );
        }

        double weight;

        // Attempt to convert the user's entry into a number
        try {
            weight = Double.parseDouble(input.trim());
        } catch (NumberFormatException e) {
            return new ValidationResult(
                    false,
                    0,
                    "Enter a valid number"
            );
        }

        // Make sure the weight is within a reasonable range
        if (weight < MIN_WEIGHT || weight > MAX_WEIGHT) {
            return new ValidationResult(
                    false,
                    0,
                    "Weight must be between 50 and 1,000 pounds"
            );
        }

        // Return the validated weight
        return new ValidationResult(
                true,
                weight,
                null
        );
    }

    // Validation Result
    public static class ValidationResult {

        private final boolean valid;
        private final double weight;
        private final String errorMessage;

        // Constructor
        public ValidationResult(
                boolean valid,
                double weight,
                String errorMessage) {

            this.valid = valid;
            this.weight = weight;
            this.errorMessage = errorMessage;
        }

        // Getters
        public boolean isValid() {
            return valid;
        }

        public double getWeight() {
            return weight;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
}