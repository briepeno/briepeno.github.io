/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: WeightInputValidatorTest.java
 * Description:
 * This class tests the WeightInputValidator to confirm that valid
 * weights are accepted and invalid entries are rejected before
 * they can reach the SQLite database.
 */

package com.cs360briannapeno.weighttrackapplication;

// Imports
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Tests the application's weight-input validation rules.
 */
public class WeightInputValidatorTest {

    // Valid Weight Test
    @Test
    public void validDecimalWeightIsAccepted() {
        WeightInputValidator.ValidationResult result =
                WeightInputValidator.validate("172.5");
        assertTrue(result.isValid());
        assertEquals(
                172.5,
                result.getWeight(),
                0.001
        );
        assertNull(result.getErrorMessage());
    }

    // Blank Input Test
    @Test
    public void blankWeightIsRejected() {
        WeightInputValidator.ValidationResult result =
                WeightInputValidator.validate("   ");
        assertFalse(result.isValid());
        assertEquals(
                "Enter a weight",
                result.getErrorMessage()
        );
    }

    // Nonnumeric Input Test
    @Test
    public void nonnumericWeightIsRejected() {
        WeightInputValidator.ValidationResult result =
                WeightInputValidator.validate("one hundred");
        assertFalse(result.isValid());
        assertEquals(
                "Enter a valid number",
                result.getErrorMessage()
        );
    }

    // Minimum Weight Test
    @Test
    public void weightBelowMinimumIsRejected() {
        WeightInputValidator.ValidationResult result =
                WeightInputValidator.validate("49");
        assertFalse(result.isValid());
        assertEquals(
                "Weight must be between 50 and 1,000 pounds",
                result.getErrorMessage()
        );
    }

    // Maximum Weight Test
    @Test
    public void weightAboveMaximumIsRejected() {
        WeightInputValidator.ValidationResult result =
                WeightInputValidator.validate("1001");
        assertFalse(result.isValid());
        assertEquals(
                "Weight must be between 50 and 1,000 pounds",
                result.getErrorMessage()
        );
    }
}
