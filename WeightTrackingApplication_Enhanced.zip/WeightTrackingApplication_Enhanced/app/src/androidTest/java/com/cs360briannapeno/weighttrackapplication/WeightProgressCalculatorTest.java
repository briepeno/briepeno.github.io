/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: WeightProgressCalculatorTest.java
 * Description:
 * This class tests the calculations used by the progress dashboard.
 * It verifies total weight change, recent trends, remaining weight,
 * goal percentage, empty data handling, and support for both
 * weight-loss and weight-gain goals.
 */

package com.cs360briannapeno.weighttrackapplication;

// Imports
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Tests the WeightProgressCalculator.
 */
public class WeightProgressCalculatorTest {

    // Weight-Loss Progress Test
    @Test
    public void calculatesWeightLossProgress() {
        List<WeightEntry> entries = Arrays.asList(
                new WeightEntry(
                        1,
                        200.0,
                        "2026-09-01"
                ),
                new WeightEntry(
                        2,
                        190.0,
                        "2026-09-08"
                ),
                new WeightEntry(
                        3,
                        185.0,
                        "2026-09-15"
                )
        );

        WeightProgressCalculator.Progress result =
                WeightProgressCalculator.calculate(
                        entries,
                        170.0
                );

        // Starting and current weights
        assertEquals(
                200.0,
                result.getStartingWeight(),
                0.001
        );
        assertEquals(
                185.0,
                result.getCurrentWeight(),
                0.001
        );

        // The user lost 15 pounds in total
        assertEquals(
                -15.0,
                result.getTotalChange(),
                0.001
        );

        // The user lost 5 pounds since the previous entry
        assertEquals(
                -5.0,
                result.getRecentChange(),
                0.001
        );

        // The user has 15 pounds remaining
        assertEquals(
                15.0,
                result.getRemainingWeight(),
                0.001
        );

        // The user completed 50 percent of the goal
        assertEquals(
                50,
                result.getProgressPercentage()
        );
        assertFalse(result.isGoalReached());
    }

    // Reached Weight-Loss Goal Test
    @Test
    public void identifiesReachedWeightLossGoal() {
        List<WeightEntry> entries = Arrays.asList(
                new WeightEntry(
                        1,
                        200.0,
                        "2026-09-01"
                ),
                new WeightEntry(
                        2,
                        168.0,
                        "2026-09-15"
                )
        );

        WeightProgressCalculator.Progress result =
                WeightProgressCalculator.calculate(
                        entries,
                        170.0
                );

        assertTrue(result.isGoalReached());
        assertEquals(
                100,
                result.getProgressPercentage()
        );
    }

    // Weight-Gain Goal Test
    @Test
    public void supportsWeightGainGoal() {
        List<WeightEntry> entries = Arrays.asList(
                new WeightEntry(
                        1,
                        120.0,
                        "2026-09-01"
                ),
                new WeightEntry(
                        2,
                        125.0,
                        "2026-09-08"
                ),
                new WeightEntry(
                        3,
                        130.0,
                        "2026-09-15"
                )
        );

        WeightProgressCalculator.Progress result =
                WeightProgressCalculator.calculate(
                        entries,
                        130.0
                );

        assertEquals(
                10.0,
                result.getTotalChange(),
                0.001
        );

        assertTrue(result.isGoalReached());

        assertEquals(
                100,
                result.getProgressPercentage()
        );
    }

    // Movement Away from Goal Test
    @Test
    public void progressDoesNotDropBelowZero() {
        List<WeightEntry> entries = Arrays.asList(
                new WeightEntry(
                        1,
                        200.0,
                        "2026-09-01"
                ),
                new WeightEntry(
                        2,
                        205.0,
                        "2026-09-15"
                )
        );

        WeightProgressCalculator.Progress result =
                WeightProgressCalculator.calculate(
                        entries,
                        170.0
                );

        assertEquals(
                0,
                result.getProgressPercentage()
        );

        assertFalse(result.isGoalReached());
    }

    // Empty Weight History Test
    @Test
    public void emptyHistoryReturnsEmptyProgress() {

        WeightProgressCalculator.Progress result =
                WeightProgressCalculator.calculate(
                        Collections.emptyList(),
                        150.0
                );

        assertFalse(result.hasWeights());
        assertTrue(result.hasGoal());

        assertEquals(
                0,
                result.getProgressPercentage()
        );

        assertFalse(result.isGoalReached());
    }

    // Missing Goal Test
    @Test
    public void handlesMissingGoalWeight() {
        List<WeightEntry> entries = Arrays.asList(
                new WeightEntry(
                        1,
                        180.0,
                        "2026-09-01"
                ),
                new WeightEntry(
                        2,
                        175.0,
                        "2026-09-15"
                )
        );
        WeightProgressCalculator.Progress result =
                WeightProgressCalculator.calculate(
                        entries,
                        null
                );

        assertTrue(result.hasWeights());
        assertFalse(result.hasGoal());
        assertEquals(
                -5.0,
                result.getTotalChange(),
                0.001
        );
        assertEquals(
                0,
                result.getProgressPercentage()
        );
    }
}