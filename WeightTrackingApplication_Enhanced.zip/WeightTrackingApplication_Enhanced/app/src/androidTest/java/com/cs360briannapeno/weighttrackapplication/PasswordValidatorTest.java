/*
 * Name: Brianna Peno
 * Course: CS 499 Computer Science Capstone
 * Project: Weight Tracking Application Enhancement
 * File: PasswordValidatorTest.java
 * Description:
 * This class tests the password-strength requirements used during
 * account creation. The tests verify that valid passwords are
 * accepted and passwords missing required elements are rejected.
 */

package com.cs360briannapeno.weighttrackapplication;

// imports
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Tests the application's password-validation rules.
 */
public class PasswordValidatorTest {

    // Valid password test
    @Test
    public void validPasswordIsAccepted() {
        PasswordValidator.ValidationResult result =
                PasswordValidator.validate("Tracker1!");
        assertTrue(result.isValid());
        assertNull(result.getErrorMessage());
    }

    // Blank password test
    @Test
    public void blankPasswordIsRejected() {
        PasswordValidator.ValidationResult result =
                PasswordValidator.validate("");
        assertFalse(result.isValid());
        assertEquals(
                "Enter a password",
                result.getErrorMessage()
        );
    }

    // Minimum length test
    @Test
    public void shortPasswordIsRejected() {
        PasswordValidator.ValidationResult result =
                PasswordValidator.validate("Tr1!");
        assertFalse(result.isValid());
        assertEquals(
                "Password must contain at least 8 characters",
                result.getErrorMessage()
        );
    }

    // Space test
    @Test
    public void passwordContainingSpacesIsRejected() {
        PasswordValidator.ValidationResult result =
                PasswordValidator.validate("Track er1!");
        assertFalse(result.isValid());
        assertEquals(
                "Password cannot contain spaces",
                result.getErrorMessage()
        );
    }

    // Uppercase letter test
    @Test
    public void passwordWithoutUppercaseIsRejected() {
        PasswordValidator.ValidationResult result =
                PasswordValidator.validate("tracker1!");
        assertFalse(result.isValid());
        assertEquals(
                "Password must contain an uppercase letter",
                result.getErrorMessage()
        );
    }

    // Lowercase letter test
    @Test
    public void passwordWithoutLowercaseIsRejected() {
        PasswordValidator.ValidationResult result =
                PasswordValidator.validate("TRACKER1!");
        assertFalse(result.isValid());
        assertEquals(
                "Password must contain a lowercase letter",
                result.getErrorMessage()
        );
    }

    // Number test
    @Test
    public void passwordWithoutNumberIsRejected() {
        PasswordValidator.ValidationResult result =
                PasswordValidator.validate("Tracker!!");
        assertFalse(result.isValid());
        assertEquals(
                "Password must contain a number",
                result.getErrorMessage()
        );
    }

    // Special character test
    @Test
    public void passwordWithoutSpecialCharacterIsRejected() {
        PasswordValidator.ValidationResult result =
                PasswordValidator.validate("Tracker12");
        assertFalse(result.isValid());
        assertEquals(
                "Password must contain a special character",
                result.getErrorMessage()
        );
    }
}