package GrandStrandSystems;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This service manages Contact records using a binary search tree.
 * Contacts can be added, searched, updated, and deleted using their
 * unique contact ID.
 */

public class ContactService {

    // Stores Contact records in a binary search tree instead of an ArrayList.
    private BinarySearchTree<Contact> contacts;

     //Creates an empty Contact service.
     //Contact IDs are used to organize records within the tree.
    public ContactService() {
        contacts = new BinarySearchTree<>(Contact::getContactId);
    }
    
     //Adds a Contact to the tree.
     //Null Contacts and duplicate IDs are rejected.
    public boolean addContact(Contact contact) {
        if (contact == null) {
            return false;
        }

        return contacts.insert(contact);
    }

    // Deletes a Contact using its unique ID.
    // Returns false if the Contact does not exist.
    public boolean deleteContact(String contactId) {
        return contacts.delete(contactId);
    }

     //Updates the fields of an existing Contact.
     //A null field keeps the Contact's existing value.
    public boolean updateContact(String contactId, String firstName,
            String lastName, String phone, String address) {
        Contact oldContact = getContact(contactId);
        // The Contact must already exist before it can be updated.
        if (oldContact == null) {
            return false;
        }

        // Keep the existing value when a new value is not provided.
        String newFirstName =
                firstName != null ? firstName : oldContact.getFirstName();
        String newLastName =
                lastName != null ? lastName : oldContact.getLastName();
        String newPhone =
                phone != null ? phone : oldContact.getPhone();
        String newAddress =
                address != null ? address : oldContact.getAddress();

        try {
             // Creating a new Contact causes the validation in the
             // Contact constructor to run before the original record
             // is replaced.
            Contact updatedContact = new Contact(
                    contactId,
                    newFirstName,
                    newLastName,
                    newPhone,
                    newAddress);

            // Replace the old Contact with the validated updated Contact.
            contacts.delete(contactId);
            contacts.insert(updatedContact);
            return true;

        } catch (IllegalArgumentException e) {
            // Invalid information will not replace the existing Contact.
            return false;
        }
    }

     //Searches for a Contact using its unique ID.
     //The BST search replaces the original ArrayList linear search.
    public Contact getContact(String contactId) {
        return contacts.search(contactId);
    }
}