package GrandStrandSystems;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This service manages Appointment records using a binary search tree.
 * Appointments can be added, searched, and deleted using their
 * unique appointment ID.
 */

public class AppointmentService {
    // Stores Appointment records in a binary search tree.
    private BinarySearchTree<Appointment> appointments;

     //Creates an empty Appointment service.
     // Appointment IDs are used to organize records within the tree.
    public AppointmentService() {
        appointments = new BinarySearchTree<>(Appointment::getApptID);
    }

     // Adds an Appointment to the tree.
     // Null Appointments and duplicate IDs are rejected.
    public boolean addAppointment(Appointment appointment) {
        if (appointment == null) {
            return false;
        }
        return appointments.insert(appointment);
    }

     // Deletes an Appointment using its unique ID.
     // Returns false if the Appointment does not exist.
    public boolean deleteAppointment(String apptID) {
        return appointments.delete(apptID);
    }

     //Searches for an Appointment using its unique ID.
     //The BST search replaces the original ArrayList linear search.
    public Appointment getAppointment(String apptID) {
        return appointments.search(apptID);
    }
}