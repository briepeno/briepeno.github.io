package GrandStrandSystems;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This service manages Task records using a binary search tree.
 * Tasks can be added, searched, updated, and deleted using
 * their unique task ID.
 */

public class TaskService {
    // Stores Task records in a binary search tree.
    private BinarySearchTree<Task> tasks;
     //Creates an empty Task service.
     //Task IDs are used to organize records within the tree. 
    public TaskService() {
        tasks = new BinarySearchTree<>(Task::getTaskID);
    }

     // Adds a Task to the tree.
     // Null Tasks and duplicate IDs are rejected.
    public boolean addTask(Task task) {
        if (task == null) {
            return false;
        }
        return tasks.insert(task);
    }

     //Deletes a Task using its unique ID.
     //Returns false if the Task does not exist.
    public boolean deleteTask(String taskID) {
        return tasks.delete(taskID);
    }

     // Updates the name and description of an existing Task.
     // A null value keeps the Task's existing information.
    public boolean updateTask(String taskID, String taskName, String taskDesc) {
        Task oldTask = getTask(taskID);
        // The Task must exist before it can be updated.
        if (oldTask == null) {
            return false;
        }

        // Keep the existing value if a new value is not provided.
        String newTaskName =
                taskName != null ? taskName : oldTask.getTaskName();
        String newTaskDesc =
                taskDesc != null ? taskDesc : oldTask.getTaskDesc();
        try {
            
             //Creating a new Task runs the validation
             //contained in the Task constructor.
            Task updatedTask =
                    new Task(taskID, newTaskName, newTaskDesc);
            // Replace the old Task with the validated updated Task.
            tasks.delete(taskID);
            tasks.insert(updatedTask);
            return true;

        } catch (IllegalArgumentException e) {
            // Invalid values will not replace the existing Task.
            return false;
        }
    }

     // Searches for a Task using its unique ID.
     // The BST search replaces the original linear ArrayList search.
    public Task getTask(String taskID) {
        return tasks.search(taskID);
    }
}