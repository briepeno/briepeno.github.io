package GrandStrandSystems;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This class represents a task record.
 * Tasks can be added, searched, updated, and deleted using
 * their unique task ID.
 */

public class Task {
	private final String taskID; //immutable unique ID
	private String taskName; //Task name
	private String taskDesc; //Task description
	
	//constructors
	public Task (String taskID, String taskName, String taskDesc) {
		//ID cannot be longer than 10 characters
		if(taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		//Name cannot be longer than 20 characters
		if(taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid Name");
		}
		//Description cannot be longer than 50 characters
		if(taskDesc == null || taskDesc.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");

		}
		this.taskID = taskID;
		this.taskName = taskName;
		this.taskDesc = taskDesc;
	}
	//getters
	public String getTaskID() {
		return taskID;
	}
	public String getTaskName() {
		return taskName;
	}
	public String getTaskDesc() {
		return taskDesc;
	}

}
