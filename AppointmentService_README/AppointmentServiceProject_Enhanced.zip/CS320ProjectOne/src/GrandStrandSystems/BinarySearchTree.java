package GrandStrandSystems;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This class implements a binary search tree that can store
 * different types of records, including Contacts, Tasks, and Appointments.
 * The tree supports inserting, searching, deleting, and traversing records
 * by their unique ID.
 */

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class BinarySearchTree<T> {

     //Represents one node in the binary search tree.
     //Each node stores the record, its unique ID,
     //and references to the left and right child nodes.
	
    private class Node {
        String id;
        T data;
        Node left;
        Node right;

         //Creates a new node with an ID and record.
        public Node(String id, T data) {
            this.id = id;
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    // The root is the starting point of the binary search tree.
    private Node root;

    // Used to retrieve the unique ID from the type of record being stored.
    private Function<T, String> idGetter;
    
     //Creates an empty binary search tree.
     //The idGetter tells the tree how to retrieve the record's unique ID.
     
    public BinarySearchTree(Function<T, String> idGetter) {
        this.root = null;
        this.idGetter = idGetter;
    }

     //Inserts a new record into the binary search tree.
     //Records with smaller IDs move left and larger IDs move right.
     // Duplicate IDs are not allowed.
     
    public boolean insert(T data) {
        // Prevent null records from being added.
        if (data == null) {
            return false;
        }

        String id = idGetter.apply(data);

        // If the tree is empty, the new record becomes the root.
        if (root == null) {
            root = new Node(id, data);
            return true;
        }

        Node current = root;

        while (true) {
            int comparison = id.compareTo(current.id);
            // Duplicate IDs are not allowed.
            if (comparison == 0) {
                return false;
            }

            // Move left if the new ID is smaller.
            if (comparison < 0) {
                if (current.left == null) {
                    current.left = new Node(id, data);
                    return true;
                }
                current = current.left;

            } else {
                // Move right if the new ID is larger.
                if (current.right == null) {
                    current.right = new Node(id, data);
                    return true;
                }
                current = current.right;
            }
        }
    }

     //Searches the binary search tree for a record using its unique ID.
     //Returns the record if it is found or null if it does not exist.
     
    public T search(String id) {
        if (id == null) {
            return null;
        }

        Node current = root;

        while (current != null) {
            int comparison = id.compareTo(current.id);
            // Record was found.
            if (comparison == 0) {
                return current.data;
            }

            // Search the left side of the tree.
            if (comparison < 0) {
                current = current.left;

            } else {
                // Search the right side of the tree.
                current = current.right;
            }
        }
        // Record was not found.
        return null;
    }

     //Deletes a record from the tree using its unique ID.
     //Returns true if the record was deleted or false if it was not found.
     
    public boolean delete(String id) {
        if (id == null || search(id) == null) {
            return false;
        }
        root = deleteNode(root, id);
        return true;
    }

    
     //Recursively removes a node from the tree.
     //Handles nodes with no children, one child, or two children.
     
    private Node deleteNode(Node node, String id) {
        if (node == null) {
            return null;
        }

        int comparison = id.compareTo(node.id);
        // Search the left subtree.
        if (comparison < 0) {
            node.left = deleteNode(node.left, id);

        // Search the right subtree.
        } else if (comparison > 0) {
            node.right = deleteNode(node.right, id);

        } else {
            // Case 1: Node has no left child.
            if (node.left == null) {
                return node.right;
            }

            // Case 2: Node has no right child.
            if (node.right == null) {
                return node.left;
            }

             // Case 3: Node has two children.
             // Find the smallest node in the right subtree
             // and use it to replace the node being deleted.
             
            Node replacement = findMinimum(node.right);
            node.id = replacement.id;
            node.data = replacement.data;
            node.right = deleteNode(node.right, replacement.id);
        }

        return node;
    }

     //Finds the node with the smallest ID in a subtree.
     //This is used when deleting a node that has two children.
    private Node findMinimum(Node node) {
        Node current = node;
        while (current.left != null) {
            current = current.left;
        }

        return current;
    }

     //Returns all records in ascending ID order
     //using an in-order traversal.
    public List<T> inOrderTraversal() {
        List<T> records = new ArrayList<>();
        inOrderTraversal(root, records);
        return records;
    }

     //Recursively performs an in-order traversal.
     //The method stops when it reaches a null child.
    private void inOrderTraversal(Node node, List<T> records) {
        // Stop when the end of a branch is reached.
        if (node == null) {
            return;
        }

        // Visit the left subtree first.
        inOrderTraversal(node.left, records);

        // Add the current node.
        records.add(node.data);

        // Visit the right subtree.
        inOrderTraversal(node.right, records);
    }
}