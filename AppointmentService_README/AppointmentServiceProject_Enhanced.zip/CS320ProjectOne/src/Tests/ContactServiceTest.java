package Tests;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * Tests the ContactService class to make sure contacts can be added,
 * retrieved, updated, and deleted correctly. It also tests invalid input
 * and duplicate or non-existent contact scenarios.
 */

import GrandStrandSystems.ContactService;
import GrandStrandSystems.Contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    private ContactService service;
    private Contact contact;

    @BeforeEach
    void setup() {
        service = new ContactService();
        contact = new Contact("49274", "Brianna", "Peno", "1867530999", "45 Scott Street");
    }

    // Test adding a valid contact
    @Test
    void testAddContact() {
        assertTrue(service.addContact(contact));
        Contact retrieved = service.getContact("49274");
        assertNotNull(retrieved);
        assertTrue(retrieved.getContactId().equals("49274"));
        assertTrue(retrieved.getFirstName().equals("Brianna"));
        assertTrue(retrieved.getLastName().equals("Peno"));
        assertTrue(retrieved.getPhone().equals("1867530999"));
        assertTrue(retrieved.getAddress().equals("45 Scott Street"));
    }

    // Test adding a duplicate contact ID
    @Test
    void testAddDuplicateContact() {
        service.addContact(contact);
        Contact duplicate = new Contact("49274", "Susan", "Smith", "1234567890", "45 S Central Street");
        assertFalse(service.addContact(duplicate));
    }

    // Test deleting a contact
    @Test
    void testDeleteContact() {
        service.addContact(contact);
        assertTrue(service.deleteContact("49274"));
        assertNull(service.getContact("49274"));
    }

    // Test deleting a non-existent contact
    @Test
    void testDeleteNonExistentContact() {
        assertFalse(service.deleteContact("99999"));
    }

    // Test updating contact successfully
    @Test
    void testUpdateContact() {
        service.addContact(contact);
        assertTrue(service.updateContact("49274", "Christina", "Duprey", "1234567890", "55 Maple Street"));

        Contact updated = service.getContact("49274");
        assertTrue(updated.getFirstName().equals("Christina"));
        assertTrue(updated.getLastName().equals("Duprey"));
        assertTrue(updated.getPhone().equals("1234567890"));
        assertTrue(updated.getAddress().equals("55 Maple Street"));
    }

    // Test updating contact with invalid fields 
    @Test
    void testUpdateContactInvalidFields() {
        service.addContact(contact);
        // firstName too long
        assertFalse(service.updateContact("49274", "Christiannamea", null, null, null));
        // lastName too long
        assertFalse(service.updateContact("49274", null, "PenoPenoPenoPeno", null, null));
        // phone invalid
        assertFalse(service.updateContact("49274", null, null, "12345", null));
        // address too long
        assertFalse(service.updateContact("49274", null, null, null, "12345 This is a very long address"));
    }

    // Test updating a non-existent contact
    @Test
    void testUpdateNonExistentContact() {
        assertFalse(service.updateContact("98745", "Benjamin", "Button", "1234567890", "1600 Pennsylvania Ave"));
    }
}