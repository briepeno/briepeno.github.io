package Tests;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This class compares the search performance of the original
 * ArrayList linear search with the enhanced binary search tree.
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import GrandStrandSystems.BinarySearchTree;
import GrandStrandSystems.Contact;

public class searchPerformanceTest {

    public static void main(String[] args) {

        final int RECORD_COUNT = 10000;
        final int SEARCH_COUNT = 20000;

        List<Contact> arrayContacts = new ArrayList<>();
        List<Contact> treeInsertionOrder = new ArrayList<>();
        
         //Create the same Contact records for both data structures.
        for (int i = 0; i < RECORD_COUNT; i++) {
            String id = String.format("%06d", i);
            Contact contact = new Contact(
                    id,
                    "John",
                    "Smith",
                    "1234567890",
                    "123 Main St");

            arrayContacts.add(contact);
            treeInsertionOrder.add(contact);
        }

         //Shuffle the insertion order so the BST does not become
         //a one-sided tree from inserting IDs in sorted order.
        Collections.shuffle(treeInsertionOrder, new Random(42));
        BinarySearchTree<Contact> tree =
                new BinarySearchTree<>(Contact::getContactId);
        for (Contact contact : treeInsertionOrder) {
            tree.insert(contact);
        }

        //Generate the same random search IDs for both structures
        //so the comparison is fair.
        Random random = new Random(42);
        String[] searchIds = new String[SEARCH_COUNT];
        for (int i = 0; i < SEARCH_COUNT; i++) {
            int idNumber = random.nextInt(RECORD_COUNT);
            searchIds[i] = String.format("%06d", idNumber);
        }

         //Warm up the JVM before measuring performance.
        for (int i = 0; i < 1000; i++) {
            linearSearch(arrayContacts, searchIds[i]);
            tree.search(searchIds[i]);
        }

         //Measure the original ArrayList linear search.
        long arrayStart = System.nanoTime();
        int arrayFound = 0;
        for (String id : searchIds) {
            if (linearSearch(arrayContacts, id) != null) {
                arrayFound++;
            }
        }
        
        long arrayEnd = System.nanoTime();

        // Measure the enhanced BST search.
        long treeStart = System.nanoTime();
        int treeFound = 0;
        for (String id : searchIds) {
            if (tree.search(id) != null) {
                treeFound++;
            }
        }

        long treeEnd = System.nanoTime();

        double arrayMilliseconds =
                (arrayEnd - arrayStart) / 1_000_000.0;
        double treeMilliseconds =
                (treeEnd - treeStart) / 1_000_000.0;
        double improvement =
                arrayMilliseconds / treeMilliseconds;

        
        // Display the results.
        System.out.println("Search Performance Comparison");
        System.out.println("-----------------------------");
        System.out.println("Records: " + RECORD_COUNT);
        System.out.println("Searches: " + SEARCH_COUNT);
        System.out.println();
        System.out.printf(
                "Original ArrayList: %.3f ms%n",
                arrayMilliseconds);
        System.out.printf(
                "Enhanced BST: %.3f ms%n",
                treeMilliseconds);
        System.out.println();
        System.out.printf(
                "BST was approximately %.2f times faster.%n",
                improvement);
        System.out.println();
        System.out.println(
                "ArrayList records found: " + arrayFound);
        System.out.println(
                "BST records found: " + treeFound);
    }

     //Recreates the linear search used by the original
     //ContactService before the BST enhancement.
    private static Contact linearSearch(
            List<Contact> contacts,
            String contactId) {
        for (Contact contact : contacts) {
            if (contact.getContactId().equals(contactId)) {
                return contact;
            }
        }

        return null;
    }
}