package Tests;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This test class verifies the BinarySearchTree implementation.
 * Tests cover insertion, searching, duplicate IDs, deletion,
 * and in-order traversal.
 */

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import GrandStrandSystems.BinarySearchTree;
import GrandStrandSystems.Contact;

class BinarySearchTreeTest {

    private BinarySearchTree<Contact> tree;
    
     //Creates a new empty tree before each test.
     //Contact IDs are used to organize records in the tree.
    @BeforeEach
    void setUp() {
        tree = new BinarySearchTree<>(Contact::getContactId);
    }

     //Tests inserting a Contact into an empty tree
     //and retrieving it using its ID.
    @Test
    void testInsertContact() {

        Contact contact = new Contact(
                "005",
                "Brianna",
                "Peno",
                "9285554525",
                "45 Scott Street");

        assertTrue(tree.insert(contact));
        assertEquals(contact, tree.search("005"));
    }

     //Tests that duplicate IDs are rejected.
    @Test
    void testDuplicateID() {

        Contact contact1 = new Contact(
        		"005",
                "Brianna",
                "Peno",
                "9285554525",
                "45 Scott Street");

        Contact contact2 = new Contact(
                "005",
                "Mickey",
                "Mouse",
                "9285551111",
                "62 Oak St");

        assertTrue(tree.insert(contact1));
        assertFalse(tree.insert(contact2));
    }

    
     //Tests searching the left side of the tree.
    @Test
    void testSearchLeft() {

        Contact root = new Contact(
        		"005",
                "Brianna",
                "Peno",
                "9285554525",
                "45 Scott Street");

        Contact left = new Contact(
        		"003",
                "Mickey",
                "Mouse",
                "9285551111",
                "62 Oak St");

        tree.insert(root);
        tree.insert(left);

        assertEquals(left, tree.search("003"));
    }

     //Tests searching the right side of the tree.
    @Test
    void testSearchRight() {

        Contact root = new Contact(
        		"005",
                "Brianna",
                "Peno",
                "9285554525",
                "45 Scott Street");

        Contact right = new Contact(
                "008",
                "Mark",
                "Brown",
                "1112223333",
                "789 Pine St");

        tree.insert(root);
        tree.insert(right);

        assertEquals(right, tree.search("008"));
    }

     //Tests searching for an ID that does not exist.
    @Test
    void testSearchNotFound() {

        Contact contact = new Contact(
        		"005",
                "Brianna",
                "Peno",
                "9285554525",
                "45 Scott Street");

        tree.insert(contact);

        assertNull(tree.search("999"));
    }

     //Tests deleting a leaf node.
     //A leaf node has no children.
    @Test
    void testDeleteLeafNode() {

        Contact root = new Contact(
        		"005",
                "Brianna",
                "Peno",
                "9285554525",
                "45 Scott Street");

        Contact leaf = new Contact(
        		"003",
                "Mickey",
                "Mouse",
                "9285551111",
                "62 Oak St");

        tree.insert(root);
        tree.insert(leaf);

        assertTrue(tree.delete("003"));
        assertNull(tree.search("003"));
    }

    
     //Tests deleting a node with one child.
    @Test
    void testDeleteNodeWithOneChild() {

        Contact root = new Contact(
        		"005",
                "Brianna",
                "Peno",
                "9285554525",
                "45 Scott Street");
        
        Contact child = new Contact(
        		"003",
                "Mickey",
                "Mouse",
                "9285551111",
                "62 Oak St");

        Contact grandchild = new Contact(
                "002",
                "Amy",
                "White",
                "2223334444",
                "12 Elm St");

        tree.insert(root);
        tree.insert(child);
        tree.insert(grandchild);

        assertTrue(tree.delete("003"));

        assertNull(tree.search("003"));
        assertEquals(grandchild, tree.search("002"));
    }

    // Tests deleting a node with two children.
    @Test
    void testDeleteNodeWithTwoChildren() {

        Contact root = new Contact(
        		"005",
                "Brianna",
                "Peno",
                "9285554525",
                "45 Scott Street");

        Contact left = new Contact(
        		"003",
                "Mickey",
                "Mouse",
                "9285551111",
                "62 Oak St");

        Contact right = new Contact(
                "008",
                "Mark",
                "Brown",
                "1112223333",
                "789 Pine St");

        tree.insert(root);
        tree.insert(left);
        tree.insert(right);

        assertTrue(tree.delete("005"));

        assertNull(tree.search("005"));
        assertEquals(left, tree.search("003"));
        assertEquals(right, tree.search("008"));
    }

     //Tests that in-order traversal returns records
     //in ascending order by ID.
    @Test
    void testInOrderTraversal() {

        Contact contact5 = new Contact(
        		"005",
                "Brianna",
                "Peno",
                "9285554525",
                "45 Scott Street");

        Contact contact3 = new Contact(
        		"003",
                "Mickey",
                "Mouse",
                "9285551111",
                "62 Oak St");

        Contact contact8 = new Contact(
                "008",
                "Mark",
                "Brown",
                "1112223333",
                "789 Pine St");

        tree.insert(contact5);
        tree.insert(contact3);
        tree.insert(contact8);

        List<Contact> contacts = tree.inOrderTraversal();

        assertEquals(3, contacts.size());

        assertEquals("003", contacts.get(0).getContactId());
        assertEquals("005", contacts.get(1).getContactId());
        assertEquals("008", contacts.get(2).getContactId());
    }
}