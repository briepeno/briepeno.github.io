package Tests;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This test class verifies the validation rules and expected behavior
 * of the Appointment class. The tests check valid appointment creation
 * as well as invalid IDs, dates, and descriptions.
 */

import GrandStrandSystems.Appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentTest {

    private Date futureDate;
    private Date pastDate;

     //Creates valid future and past dates before each test.
     //The future date is generated relative to the current date
     //so the tests remain valid over time.
    @BeforeEach
    void setup() throws ParseException {
        SimpleDateFormat sdf =
                new SimpleDateFormat("yyyy-MM-dd HH:mm");
        // Create a valid date one day in the future.
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        futureDate = calendar.getTime();
        // Create a known date in the past.
        pastDate = sdf.parse("2000-01-01 10:00");
    }

    
     //Tests that a valid Appointment is created
     //and stores the expected values.
    @Test
    void testValidAppointment() {
        Appointment appt =
                new Appointment(
                        "A1B2C3",
                        futureDate,
                        "appointment");

        assertEquals("A1B2C3", appt.getApptID());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("appointment", appt.getApptDesc());
    }

    
    // Tests that a null appointment ID is rejected.
    @Test
    void testNullIDThrows() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        null,
                        futureDate,
                        "Description"));
    }

     //Tests that an appointment ID longer than
     //the allowed length is rejected.
    @Test
    void testTooLongIDThrows() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "IDISWAYTOOLONGTOWORK",
                        futureDate,
                        "Description"));
    }

    
     //Tests that a null appointment date is rejected.
    @Test
    void testNullDateThrows() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "ID123",
                        null,
                        "Description"));
    }

    
     //Tests that an appointment date in the past is rejected.
    @Test
    void testPastDateThrows() {

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "ID123",
                        pastDate,
                        "Description"));
    }

     //Tests that a null appointment description is rejected.
    @Test
    void testNullDescriptionThrows() {

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "ID123",
                        futureDate,
                        null));
    }

     //Tests that a description longer than
     //the allowed 50-character limit is rejected.
    @Test
    void testTooLongDescriptionThrows() {
        String longDesc =
                "This description is way too long and exceeds the fifty character limit.";
        assertTrue(longDesc.length() > 50);
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "ID123",
                        futureDate,
                        longDesc));
    }
}