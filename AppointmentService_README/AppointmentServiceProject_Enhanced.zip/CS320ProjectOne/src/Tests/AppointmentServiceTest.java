package Tests;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This class tests the AppointmentService methods for adding
 * and deleting appointment records.
 */

import GrandStrandSystems.AppointmentService;
import GrandStrandSystems.Appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appt;

     //Creates a new AppointmentService and a valid future
     //Appointment before each test.
    @BeforeEach
    void setup() {
        service = new AppointmentService();

        // Create a date one day in the future.
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date futureDate = calendar.getTime();

        appt = new Appointment(
                "8675309",
                futureDate,
                "appointment");
    }

    // Test adding an appointment.
    @Test
    void testAddAppointment() {
        assertTrue(service.addAppointment(appt));
    }

    // Test adding an appointment with a duplicate ID.
    @Test
    void testAddDuplicateAppointment() {
        service.addAppointment(appt);
        // Create another valid future date.
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 2);
        Date futureDate = calendar.getTime();

        Appointment duplicate = new Appointment(
                "8675309",
                futureDate,
                "Duplicate appointment");
        assertFalse(service.addAppointment(duplicate));
    }

    // Test deleting an appointment.
    @Test
    void testDeleteAppointment() {
        service.addAppointment(appt);
        assertTrue(service.deleteAppointment("8675309"));
        // After deletion, attempting to delete again should fail.
        assertFalse(service.deleteAppointment("8675309"));
    }

    // Test deleting an appointment that does not exist.
    @Test
    void testDeleteNonExistentAppointment() {
        assertFalse(service.deleteAppointment("Doesn't Exist"));
    }
}