package Tests;

/*
 * Brianna Peno
 * CS 499 Computer Science Capstone
 * Enhancement Two: Algorithms and Data Structures
 * This test class verifies the validation rules and expected behavior
 * of the Contact class. The tests check valid Contact creation
 * as well as invalid IDs, names, phone numbers, and addresses. 
 */

import GrandStrandSystems.Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
    void testValidContactCreation() {
		Contact contact = new Contact("49274", "Brianna", "Peno", "1867530999", "45 Scott Street");
        assertTrue(contact.getContactId().equals("49274"));
        assertTrue(contact.getFirstName().equals("Brianna"));
        assertTrue(contact.getLastName().equals("Peno"));
        assertTrue(contact.getPhone().equals("1867530999"));
        assertTrue(contact.getAddress().equals("45 Scott Street"));
    }

	// Test contactId length > 10
    @Test
    void testContactIdTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Brianna", "Peno", "1867530999", "45 Scott Street");
        });
    }

    // Test firstName length > 10
    @Test
    void testFirstNameTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("49274", "Christianna", "Peno", "1867530999", "45 Scott Street");
        });
    }

    // Test lastName length > 10
    @Test
    void testLastNameTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("49274", "Brianna", "Penopenopeno", "1867530999", "45 Scott Street");
        });
    }

    // Test phone not exactly 10 digits
    @Test
    void testPhoneMustBeExactlyTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("49274", "Brianna", "Peno", "8675309", "45 Scott Street");
        });
    }

    // Test address length > 30
    @Test
    void testAddressTooLongThrowsException() {
        String longAddress = "123456789 Long Meadows Field Street"; // 31 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("49274", "Brianna", "Peno", "1867530999", longAddress);
        });
    }

    // Test null values for all fields
    @Test
    void testNullValuesThrowException() {
        // contactId null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Brianna", "Peno", "1867530999", "45 Scott Street");
        });

        // firstName null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("49274", null, "Peno", "1867530999", "45 Scott Street");
        });

        // lastName null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("49274", "Brianna", null, "1867530999", "45 Scott Street");
        });

        // phone null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("49274", "Brianna", "Peno", null, "45 Scott Street");
        });

        // address null
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("49274", "Brianna", "Peno", "1867530999", null);
        });
    }

}