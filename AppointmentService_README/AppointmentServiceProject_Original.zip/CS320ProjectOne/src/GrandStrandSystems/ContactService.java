package GrandStrandSystems;
//Brianna Peno Project One
import java.util.ArrayList;
import java.util.List;

public class ContactService {

    private List<Contact> contacts;

    public ContactService() {
        contacts = new ArrayList<>();
    }

    // Add a contact (ID must be unique)
    public boolean addContact(Contact contact) {
        if (contact == null || getContact(contact.getContactId()) != null) {
            return false; // Null or duplicate ID
        }
        contacts.add(contact);
        return true;
    }

    // Delete a contact by ID
    public boolean deleteContact(String contactId) {
        Contact toDelete = getContact(contactId);
        if (toDelete == null) {
            return false; // ID not found
        }
        contacts.remove(toDelete);
        return true;
    }

    // Update contact fields by ID
    public boolean updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact oldContact = getContact(contactId);
        if (oldContact == null) {
            return false; // ID not found
        }

        String newFirstName = firstName != null ? firstName : oldContact.getFirstName();
        String newLastName = lastName != null ? lastName : oldContact.getLastName();
        String newPhone = phone != null ? phone : oldContact.getPhone();
        String newAddress = address != null ? address : oldContact.getAddress();

        try {
            Contact updatedContact = new Contact(contactId, newFirstName, newLastName, newPhone, newAddress);
            // Replace old contact
            contacts.remove(oldContact);
            contacts.add(updatedContact);
            return true;
        } catch (IllegalArgumentException e) {
            return false; // Invalid field values
        }
    }

    // Get a contact by ID
    public Contact getContact(String contactId) {
        for (Contact c : contacts) {
            if (c.getContactId().equals(contactId)) {
                return c;
            }
        }
        return null; // Not found
    }
}
