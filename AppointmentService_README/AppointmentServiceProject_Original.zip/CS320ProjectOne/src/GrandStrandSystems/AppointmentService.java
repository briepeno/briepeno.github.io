package GrandStrandSystems;
//Brianna Peno Project One
import java.util.ArrayList;
import java.util.List;

public class AppointmentService {

    private List<Appointment> appointments;

    public AppointmentService() {
        appointments = new ArrayList<>();
    }

    // Add an appointment with ID
    public boolean addAppointment(Appointment appointment) {
        for (Appointment a : appointments) {
            if (a.getApptID().equals(appointment.getApptID())) {
                return false; // Duplicate ID
            }
        }
        appointments.add(appointment);
        return true;
    }

    // Delete an appointment by ID
    public boolean deleteAppointment(String apptID) {
        for (Appointment a : appointments) {
            if (a.getApptID().equals(apptID)) {
                appointments.remove(a);
                return true; // Deleted successfully
            }
        }
        return false; // ID not found
    }
}

