package GrandStrandSystems;
// Brianna Peno Project One
import java.util.Date;

public class Appointment {
    private final String apptID;      // immutable unique ID
    private Date appointmentDate;      // Appointment date
    private String apptDesc;           // Appointment description

    // Constructor
    public Appointment(String apptID, Date appointmentDate, String apptDesc) {
        // ID cannot be null or longer than 10 characters
        if (apptID == null || apptID.length() > 10) {
            throw new IllegalArgumentException("Invalid Appointment ID");
        }
        
        // Appointment date cannot be null or in the past
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date cannot be null");
        }
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past");
        }

        // Description cannot be null or longer than 50 characters
        if (apptDesc == null || apptDesc.length() > 50) {
            throw new IllegalArgumentException("Invalid Appointment Description");
        }

        this.apptID = apptID;
        this.appointmentDate = appointmentDate;
        this.apptDesc = apptDesc;
    }

    // Getters
    public String getApptID() {
        return apptID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getApptDesc() {
        return apptDesc;
    }

}