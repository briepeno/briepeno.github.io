package GrandStrandSystems;
// Brianna Peno Project One

import java.util.ArrayList;
import java.util.List;

public class TaskService {

    private List<Task> tasks;

    public TaskService() {
        tasks = new ArrayList<>();
    }

    // Add a task (ID must be unique)
    public boolean addTask(Task task) {
        if (task == null || getTask(task.getTaskID()) != null) {
            return false; // Null task or duplicate ID
        }
        tasks.add(task);
        return true;
    }

    // Delete a task by ID
    public boolean deleteTask(String taskID) {
        Task toDelete = getTask(taskID);
        if (toDelete == null) {
            return false; // ID not found
        }
        tasks.remove(toDelete);
        return true;
    }

    // Update task fields by ID
    // Only name and description are updatable
    public boolean updateTask(String taskID, String newName, String newDesc) {
        Task oldTask = getTask(taskID);
        if (oldTask == null) {
            return false; // ID not found
        }

        // Use old values if new values are null
        String updatedName = newName != null ? newName : oldTask.getTaskName();
        String updatedDesc = newDesc != null ? newDesc : oldTask.getTaskDesc();

        try {
            // Create a temporary Task to validate the new values
            Task updatedTask = new Task(taskID, updatedName, updatedDesc);
            // Replace old task
            tasks.remove(oldTask);
            tasks.add(updatedTask);
            return true;
        } catch (IllegalArgumentException e) {
            return false; // Invalid field values
        }
    }

    // Get a task by ID
    public Task getTask(String taskID) {
        for (Task t : tasks) {
            if (t.getTaskID().equals(taskID)) {
                return t;
            }
        }
        return null; // Not found
    }
}
