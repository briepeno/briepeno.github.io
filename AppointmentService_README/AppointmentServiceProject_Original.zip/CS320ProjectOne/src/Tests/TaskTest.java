package Tests;

import GrandStrandSystems.Task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("8675309", "CS 320 Module 4", "This is a test for the task description");
        assertTrue(task.getTaskID().equals("8675309"));
        assertTrue(task.getTaskName().equals("CS 320 Module 4"));
        assertTrue(task.getTaskDesc().equals("This is a test for the task description"));
    }

    // Test taskID length > 10
    @Test
    void testTaskIDTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "CS 320", "Description");
        });
    }

    // Test taskName length > 20
    @Test
    void testTaskNameTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("8675309", "This task name is definitely too long", "Description");
        });
    }

    // Test taskDesc length > 50
    @Test
    void testTaskDescTooLongThrowsException() {
        String longDesc = "This description is way too long and exceeds the fifty character limit";
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("8675309", "CS 320", longDesc);
        });
    }

    // Test null values for all fields
    @Test
    void testNullValuesThrowException() {
        // taskID null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "CS 320", "Description");
        });

        // taskName null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("8675309", null, "Description");
        });

        // taskDesc null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("8675309", "CS 320", null);
        });
    }
}