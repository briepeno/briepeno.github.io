package Tests;

import GrandStrandSystems.TaskService;
import GrandStrandSystems.Task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

    private TaskService service;
    private Task task;

    @BeforeEach
    void setup() {
        service = new TaskService();
        task = new Task("8675309", "CS 320 Module 4", "This is a test for the task description");
    }

    // Test adding a valid task
    @Test
    void testAddTask() {
        assertTrue(service.addTask(task));
        Task retrieved = service.getTask("8675309");
        assertNotNull(retrieved);
        assertTrue(retrieved.getTaskID().equals("8675309"));
        assertTrue(retrieved.getTaskName().equals("CS 320 Module 4"));
        assertTrue(retrieved.getTaskDesc().equals("This is a test for the task description"));
    }

    // Test adding a duplicate task ID
    @Test
    void testAddDuplicateTask() {
        service.addTask(task);
        Task duplicate = new Task("8675309", "Another Silly Task", "Duplicate ID test");
        assertFalse(service.addTask(duplicate));
    }

    // Test deleting a task
    @Test
    void testDeleteTask() {
        service.addTask(task);
        assertTrue(service.deleteTask("8675309"));
        assertNull(service.getTask("8675309"));
    }

    // Test deleting a non-existent task
    @Test
    void testDeleteNonExistentTask() {
        assertFalse(service.deleteTask("9999999"));
    }

    // Test updating task successfully
    @Test
    void testUpdateTask() {
        service.addTask(task);
        assertTrue(service.updateTask("8675309", "Updated task name", "Updated task description"));

        Task updated = service.getTask("8675309");
        assertTrue(updated.getTaskName().equals("Updated task name"));
        assertTrue(updated.getTaskDesc().equals("Updated task description"));
    }

    // Test updating task with invalid fields
    @Test
    void testUpdateTaskInvalidFields() {
        service.addTask(task);
        // taskName too long
        assertFalse(service.updateTask("8675309", "This task name is definitely way too long", null));
        // taskDesc too long
        String longDesc = "This description is way too long and exceeds the fifty character limit";
        assertFalse(service.updateTask("8675309", null, longDesc));
    }

    // Test updating a non-existent task
    @Test
    void testUpdateNonExistentTask() {
        assertFalse(service.updateTask("1234567", "Nonexistent Task", "Description"));
    }
}
