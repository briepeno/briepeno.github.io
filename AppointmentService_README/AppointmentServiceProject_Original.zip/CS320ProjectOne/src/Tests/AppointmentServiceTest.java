package Tests;

import GrandStrandSystems.AppointmentService;
import GrandStrandSystems.Appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appt;

    @BeforeEach
    void setup() throws Exception {
        service = new AppointmentService();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date futureDate = sdf.parse("2026-01-01 10:00");

        appt = new Appointment("8675309", futureDate, "appointment");
    }

    // Test adding an appointment
    @Test
    void testAddAppointment() {
        assertTrue(service.addAppointment(appt));
    }

    // Test adding a duplicate appointment ID
    @Test
    void testAddDuplicateAppointment() throws Exception {
        service.addAppointment(appt);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date futureDate = sdf.parse("2026-01-02 11:00");

        Appointment duplicate = new Appointment("8675309", futureDate, "Duplicate appointment");
        assertFalse(service.addAppointment(duplicate));
    }

    // Test deleting an appointment
    @Test
    void testDeleteAppointment() {
        service.addAppointment(appt);
        assertTrue(service.deleteAppointment("8675309"));
        // After deletion, attempting to delete again should fail
        assertFalse(service.deleteAppointment("8675309"));
    }

    // Test deleting a non-existent appointment
    @Test
    void testDeleteNonExistentAppointment() {
        assertFalse(service.deleteAppointment("Doesn't Exist"));
    }
}
