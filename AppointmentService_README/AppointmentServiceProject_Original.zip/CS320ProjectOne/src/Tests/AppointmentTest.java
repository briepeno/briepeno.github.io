package Tests;

import GrandStrandSystems.Appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentTest {

    private Date futureDate;
    private Date pastDate;

    @BeforeEach
    void setup() throws ParseException {
        // Use fixed real dates for testing
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        // Future date
        futureDate = sdf.parse("2026-01-01 10:00");

        // Past date
        pastDate = sdf.parse("2000-01-01 10:00");
    }

    @Test
    void testValidAppointment() {
        Appointment appt = new Appointment("A1B2C3", futureDate, "appointment");
        assertEquals("A1B2C3", appt.getApptID());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("appointment", appt.getApptDesc());
    }

    @Test
    void testNullIDThrows() {
    	// ID NULL
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, futureDate, "Description")
        );
    }

    @Test
    void testTooLongIDThrows() {
        // ID too long
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("IDISWAYTOOLONGTOWORK", futureDate, "Description")
        );
    }

    @Test
    void testNullDateThrows() {
    	// Date NULL
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("ID123", null, "Description")
        );
    }

    @Test
    void testPastDateThrows() {
    	// Test past date
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("ID123", pastDate, "Description")
        );
    }

    @Test
    void testNullDescriptionThrows() {
    	// Description NULL
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("ID123", futureDate, null)
        );
    }

    @Test
    void testTooLongDescriptionThrows() {
    	// Test long description 
        String longDesc = "This description is way too long and exceeds the fifty character limit.";
        assertTrue(longDesc.length() > 50);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("ID123", futureDate, longDesc)
        );
    }

}
