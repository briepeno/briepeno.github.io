package com.cs360briannapeno.weighttrackapplication;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private TextView textCurrentWeight, textGoalWeight;
    private Database db;

    private static final int SMS_PERMISSION_CODE = 200;
    private boolean smsSent = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Hide Action Bar
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        textCurrentWeight = findViewById(R.id.textCurrentWeight);
        textGoalWeight = findViewById(R.id.textGoalWeight);
        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);

        db = new Database(this);

        // Highlight Home tab
        bottomNav.setSelectedItemId(R.id.nav_home);

        // Bottom Navigation Listener
        bottomNav.setOnItemSelectedListener(item -> {

            int id = item.getItemId();

            if (id == R.id.nav_home) {
                return true;
            }
            else if (id == R.id.nav_add_weight) {
                startActivity(new Intent(this, AddWeightActivity.class));
                return true;
            }
            else if (id == R.id.nav_goal_weight) {
                startActivity(new Intent(this, GoalWeightActivity.class));
                return true;
            }
            else if (id == R.id.nav_settings) {
                startActivity(new Intent(this, NotificationsActivity.class));
                return true;
            }

            return false;
        });

        displayWeights();
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayWeights();
    }

    private void displayWeights() {

        Double latestWeight = db.getLatestWeight();
        Double goalWeight = db.getGoalWeight();

        textCurrentWeight.setText(latestWeight != null ? String.valueOf(latestWeight) : "No data");
        textGoalWeight.setText(goalWeight != null ? String.valueOf(goalWeight) : "Not set");

        if (latestWeight != null && goalWeight != null &&
                latestWeight <= goalWeight && !smsSent) {

            checkPermissionAndSendSms(goalWeight);
        }
    }

    private void checkPermissionAndSendSms(Double goalWeight) {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);

        } else {
            sendGoalSms(goalWeight);
        }
    }

    private void sendGoalSms(Double goalWeight) {

        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String phoneNumber = prefs.getString("sms_phone_number", null);

        if (phoneNumber == null || phoneNumber.isEmpty()) {
            Toast.makeText(this, "No phone number saved in settings.", Toast.LENGTH_LONG).show();
            return;
        }

        String message = "Congratulations! You reached your goal weight of "
                + goalWeight + " lbs!";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this, "Goal reached! SMS sent.", Toast.LENGTH_LONG).show();
            smsSent = true;

        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Double goalWeight = db.getGoalWeight();
                if (goalWeight != null) {
                    sendGoalSms(goalWeight);
                }

            } else {
                Toast.makeText(this,
                        "SMS permission denied",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}
