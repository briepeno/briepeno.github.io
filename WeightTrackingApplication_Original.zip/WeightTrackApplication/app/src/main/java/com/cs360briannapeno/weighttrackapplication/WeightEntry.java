package com.cs360briannapeno.weighttrackapplication;

public class WeightEntry {
    private int id;
    private double weight;
    private String date;

    public WeightEntry(int id, double weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public double getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }
}
