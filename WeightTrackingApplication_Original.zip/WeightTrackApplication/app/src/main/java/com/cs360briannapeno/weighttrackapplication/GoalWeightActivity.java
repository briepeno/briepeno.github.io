package com.cs360briannapeno.weighttrackapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class GoalWeightActivity extends AppCompatActivity {

    private EditText etGoalWeight;
    private Button btnSaveGoal;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goalweight);

        // Hide Action Bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Initialize views
        etGoalWeight = findViewById(R.id.etGoalWeight);
        btnSaveGoal = findViewById(R.id.btnSaveGoal);
        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);

        db = new Database(this);

        // Highlight correct tab
        bottomNav.setSelectedItemId(R.id.nav_goal_weight);

        // Bottom Navigation Listener
        bottomNav.setOnItemSelectedListener(item -> {

            int id = item.getItemId();

            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                return true;
            }
            else if (id == R.id.nav_add_weight) {
                startActivity(new Intent(this, AddWeightActivity.class));
                return true;
            }
            else if (id == R.id.nav_goal_weight) {
                return true; // already here
            }
            else if (id == R.id.nav_settings) {
                startActivity(new Intent(this, NotificationsActivity.class));
                return true;
            }

            return false;
        });

        // Save Goal Button
        btnSaveGoal.setOnClickListener(v -> {

            String goalStr = etGoalWeight.getText().toString().trim();

            if (goalStr.isEmpty()) {
                Toast.makeText(this, "Enter a goal weight", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double goal = Double.parseDouble(goalStr);

                if (db.setGoalWeight(goal)) {
                    Toast.makeText(this, "Goal saved!", Toast.LENGTH_SHORT).show();
                    etGoalWeight.setText("");
                } else {
                    Toast.makeText(this, "Error saving goal", Toast.LENGTH_SHORT).show();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
