package com.cs360briannapeno.weighttrackapplication;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import android.telephony.SmsManager;

public class AddWeightActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private EditText editWeight;
    private Button buttonAddWeight;
    private RecyclerView recyclerWeightList;
    private WeightAdapter adapter;
    private Database db;

    private SharedPreferences sharedPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Hide action bar
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        editWeight = findViewById(R.id.editWeight);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        recyclerWeightList = findViewById(R.id.recyclerWeightList);
        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);

        db = new Database(this);
        adapter = new WeightAdapter(db);
        recyclerWeightList.setLayoutManager(new LinearLayoutManager(this));
        recyclerWeightList.setAdapter(adapter);

        sharedPrefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE);

        // Highlight correct tab
        bottomNav.setSelectedItemId(R.id.nav_add_weight);

        // Bottom navigation listener
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                return true;
            } else if (id == R.id.nav_add_weight) {
                return true; // already here
            } else if (id == R.id.nav_goal_weight) {
                startActivity(new Intent(this, GoalWeightActivity.class));
                return true;
            } else if (id == R.id.nav_settings) {
                startActivity(new Intent(this, NotificationsActivity.class));
                return true;
            }
            return false;
        });

        // Add weight button
        buttonAddWeight.setOnClickListener(v -> {
            String weightStr = editWeight.getText().toString().trim();
            if (weightStr.isEmpty()) {
                Toast.makeText(this, "Enter a weight", Toast.LENGTH_SHORT).show();
                return;
            }

            double weight;
            try {
                weight = Double.parseDouble(weightStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.addWeight(weight)) {
                Toast.makeText(this, "Weight added!", Toast.LENGTH_SHORT).show();
                editWeight.setText("");
                adapter.notifyDataSetChanged();

                // Check goal weight
                Double goalWeight = db.getGoalWeight();
                if (goalWeight != null && weight <= goalWeight) {
                    sendGoalSmsIfAllowed(goalWeight);
                }
            } else {
                Toast.makeText(this, "Error adding weight", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendGoalSmsIfAllowed(Double goalWeight) {
        String phoneNumber = sharedPrefs.getString("sms_phone_number", "");
        if (phoneNumber.isEmpty()) return; // no number entered

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            sendGoalSms(phoneNumber, goalWeight);
        }
    }

    private void sendGoalSms(String phoneNumber, Double goalWeight) {
        String message = "Congratulations! You reached your goal weight of " + goalWeight + " lbs!";
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Goal reached! SMS sent to " + phoneNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    // Handle SMS permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Double goalWeight = db.getGoalWeight();
                String phoneNumber = sharedPrefs.getString("sms_phone_number", "");
                if (!phoneNumber.isEmpty() && goalWeight != null) {
                    sendGoalSms(phoneNumber, goalWeight);
                }
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
