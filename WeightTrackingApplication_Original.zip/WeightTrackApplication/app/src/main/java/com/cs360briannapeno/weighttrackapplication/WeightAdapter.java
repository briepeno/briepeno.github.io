package com.cs360briannapeno.weighttrackapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;

import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private ArrayList<WeightItem> weightList;
    private Database db;

    public WeightAdapter(Database db) {
        this.db = db;
        loadWeights();
    }

    private void loadWeights() {
        weightList = new ArrayList<>();
        Cursor cursor = db.getAllWeights();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            double weight = cursor.getDouble(1);
            String date = cursor.getString(2);
            weightList.add(new WeightItem(id, weight, date));
        }
        cursor.close();
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_delete, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightItem item = weightList.get(position);
        holder.textWeight.setText(item.getWeight() + " kg (" + item.getDate() + ")");
        holder.btnDelete.setOnClickListener(v -> {
            db.deleteWeight(item.getId());
            weightList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, weightList.size());
        });
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView textWeight;
        ImageButton btnDelete;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            textWeight = itemView.findViewById(R.id.textWeightValue);
            btnDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }

    // Weight item model
    static class WeightItem {
        private int id;
        private double weight;
        private String date;

        public WeightItem(int id, double weight, String date) {
            this.id = id;
            this.weight = weight;
            this.date = date;
        }

        public int getId() {
            return id;
        }

        public double getWeight() {
            return weight;
        }

        public String getDate() {
            return date;
        }
    }
}
