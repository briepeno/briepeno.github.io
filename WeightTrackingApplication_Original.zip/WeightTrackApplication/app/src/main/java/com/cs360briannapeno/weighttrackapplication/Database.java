package com.cs360briannapeno.weighttrackapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users table
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT," +
                "password TEXT)");

        // Weight entries
        db.execSQL("CREATE TABLE weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "weight REAL," +
                "date TEXT)");

        // Goal weight
        db.execSQL("CREATE TABLE goal (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "goalWeight REAL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS goal");
        onCreate(db);
    }

    // Register user
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);
        db.close();
        return result != -1;
    }

    // Login user
    public boolean loginUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("users",
                new String[]{"id"},
                "username=? AND password=?",
                new String[]{username, password},
                null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // Add weight
    public boolean addWeight(double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("weight", weight);
        values.put("date", java.time.LocalDate.now().toString());
        long result = db.insert("weights", null, values);
        db.close();
        return result != -1;
    }

    // Delete weight by id
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("weights", "id=?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }

    // Get latest weight
    public Double getLatestWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT weight FROM weights ORDER BY id DESC LIMIT 1", null);
        Double weight = null;
        if (cursor.moveToFirst()) {
            weight = cursor.getDouble(0);
        }
        cursor.close();
        db.close();
        return weight;
    }

    // Get goal weight
    public Double getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT goalWeight FROM goal ORDER BY id DESC LIMIT 1", null);
        Double weight = null;
        if (cursor.moveToFirst()) {
            weight = cursor.getDouble(0);
        }
        cursor.close();
        db.close();
        return weight;
    }

    // Set goal weight
    public boolean setGoalWeight(double goal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("goalWeight", goal);
        long result = db.insert("goal", null, values);
        db.close();
        return result != -1;
    }

    // Get all weights
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT id, weight, date FROM weights ORDER BY id DESC", null);
    }
}
