package com.cs360briannapeno.weighttrackapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class NotificationsActivity extends AppCompatActivity {

    private EditText editPhoneNumber;
    private Button buttonEnableSms;
    private SharedPreferences sharedPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        // Hide Action Bar
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonEnableSms = findViewById(R.id.buttonEnableSms);
        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);

        // Highlight correct tab
        bottomNav.setSelectedItemId(R.id.nav_settings);

        sharedPrefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE);

        // Load saved number if exists
        String savedNumber = sharedPrefs.getString("sms_phone_number", "");
        editPhoneNumber.setText(savedNumber);

        // Bottom Navigation Listener
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                return true;
            } else if (id == R.id.nav_add_weight) {
                startActivity(new Intent(this, AddWeightActivity.class));
                return true;
            } else if (id == R.id.nav_goal_weight) {
                startActivity(new Intent(this, GoalWeightActivity.class));
                return true;
            } else if (id == R.id.nav_settings) {
                return true; // already here
            }
            return false;
        });

        // Enable SMS Notifications Button
        buttonEnableSms.setOnClickListener(v -> {
            String phone = editPhoneNumber.getText().toString().trim();
            if (phone.isEmpty()) {
                Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show();
                return;
            }

            sharedPrefs.edit().putString("sms_phone_number", phone).apply();
            Toast.makeText(this, "SMS notifications enabled for: " + phone, Toast.LENGTH_SHORT).show();
        });
    }
}
