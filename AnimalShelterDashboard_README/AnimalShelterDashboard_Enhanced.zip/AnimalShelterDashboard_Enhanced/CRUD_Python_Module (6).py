# =========================================================
# CRUD PYTHON MODULE
# Handles:
# - Animal Create, Read, Update, Delete operations
# - Dashboard user creation
# - Dashboard user authentication
# =========================================================

from pymongo import MongoClient
import bcrypt

class AnimalShelter:
    """CRUD operations for the AAC MongoDB database."""

    def __init__(self):

        # -------------------------------------------------
        # MONGODB CONNECTION SETTINGS
        # These credentials allow the Python application
        # to connect to MongoDB.
        # -------------------------------------------------

        USER = 'aacuser' 
        PASS = 'BriannaPenoCS340' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 

        # Connect to MongoDB.
        self.client = MongoClient(
            'mongodb://%s:%s@%s:%d'
            % (USER, PASS, HOST, PORT)
        )

        # Select the AAC database.
        self.database = self.client[DB]

        # Animal collection used for CRUD operations.
        self.collection = self.database['animals']

        # Separate collection used for dashboard users.
        self.users_collection = self.database['users']

        # Make usernames unique.
        self.users_collection.create_index(
            "username",
            unique=True
        )

    # =====================================================
    # CREATE ANIMAL
    # =====================================================

    def create(self, data):
        """Insert one new animal document."""
        if data is None:
            return False
        try:
            self.collection.insert_one(data)
            return True
        except Exception as e:
            print(e)
            return False

    # =====================================================
    # READ ANIMALS
    # =====================================================

    def read(self, query):
        """Return animal documents matching the query."""
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(e)
            return []

    # =====================================================
    # UPDATE ANIMAL
    # =====================================================

    def update(
        self,
        query,
        update_data,
        update_many=False
    ):
        """Update one animal record by default."""
        if query is None or update_data is None:
            return 0
        try:
            if update_many:
                result = self.collection.update_many(
                    query,
                    update_data
                )
            else:
                result = self.collection.update_one(
                    query,
                    update_data
                )
            return result.modified_count
        except Exception as e:
            print(e)
            return 0

    # =====================================================
    # DELETE ANIMAL
    # =====================================================

    def delete(
        self,
        query,
        delete_many=False
    ):
        """Delete one animal record by default."""

        if query is None:
            return 0
        try:
            if delete_many:
                result = self.collection.delete_many(
                    query
                )
            else:
                result = self.collection.delete_one(
                    query
                )
            return result.deleted_count
        except Exception as e:
            print(e)
            return 0

    # =====================================================
    # CREATE DASHBOARD USER
    # =====================================================

    def create_user(
        self,
        username,
        password,
        role="editor"
    ):
        """
        Create a dashboard user.
        The plaintext password is never stored.
        bcrypt converts it into a secure password hash.
        """
        # Basic validation.
        if not username or not password:
            return False
        # Normalize username so Brianna and brianna
        # are treated as the same account.
        username = username.strip().lower()
        try:
            # Do not allow duplicate usernames.
            existing_user = (
                self.users_collection.find_one(
                    {
                        "username": username
                    }
                )
            )
            if existing_user:
                return False
            # Convert password to bytes and hash it.
            password_hash = bcrypt.hashpw(
                password.encode('utf-8'),
                bcrypt.gensalt()
            )  
            # Store the hash as a string in MongoDB.
            user_document = {
                "username":
                    username,
                "password_hash":
                    password_hash.decode(
                        'utf-8'
                    ),
                "role":
                    role
            }
            self.users_collection.insert_one(
                user_document
            )
            return True
        except Exception as e:
            print(e)
            return False

    # =====================================================
    # AUTHENTICATE DASHBOARD USER
    # =====================================================

    def authenticate_user(
        self,
        username,
        password
    ):
        """
        Check an entered username and password.

        Returns basic user information when successful.
        Returns None when authentication fails.
        """

        if not username or not password:
            return None
        username = username.strip().lower()
        try:
            # Look for the username in MongoDB.
            user = self.users_collection.find_one(
                {
                    "username": username
                }
            )
            # Username does not exist.
            if user is None:
                return None
            # Compare the entered password with
            # the stored bcrypt hash.
            password_matches = bcrypt.checkpw(
                password.encode('utf-8'),
                user[
                    "password_hash"
                ].encode('utf-8')
            )
            if password_matches:
                # Return only information that the
                # dashboard actually needs.
                return {
                    "username":
                        user["username"],
                    "role":
                        user.get(
                            "role",
                            "editor"
                        )
                }
            return None
        except Exception as e:
            print(e)
            return None